StimCom SDK for Android
========================

## Developing the SDK

- [Git usage recommendations](docs/git-usage.md)
- [How to build the SDK](docs/how-to-build.md)

## Using the SDK

- [Getting started](docs/getting-started.md)

## More information

- [Changelog](docs/changelog.md)