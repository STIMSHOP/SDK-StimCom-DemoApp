package com.stimcom.sdk.common.configuration;

/**
 * Thrown when a configuration is not valid (e.g. missing required value, invalid value, etc.)
 * <p/>
 * Created by vprat on 01/07/2015.
 */
public class InvalidConfigurationException extends RuntimeException {

    /**
     * Constructor
     *
     * @param detailMessage Some more info about the error
     */
    public InvalidConfigurationException(String detailMessage) {
        super(detailMessage);
    }
}
