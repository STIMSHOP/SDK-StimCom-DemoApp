package com.stimcom.sdk.audio.emission;

import com.stimcom.sdk.audio.utils.Indices;
import com.stimcom.sdk.audio.utils.TsUtils;
import com.stimcom.sdk.audio.utils.resampler.Resampler;

import java.util.List;

/**
 * Created by Romain on 12/10/2015.
 */
public class AudioCode {

    float[] initChirp;
    int blockSize, targetSampleRate, nativeSampleRate;
    double f1, f2, gap;
    int nbFreq;
    double[] freqs;

    public AudioCode(int blockSize, int nativeSampleRate, int targetSampleRate, int nbFreq, double startFreq, double gap) {
        this.blockSize = blockSize;
        this.nativeSampleRate = nativeSampleRate;
        this.targetSampleRate = targetSampleRate;
        this.nbFreq = nbFreq;
        this.f1 = startFreq;
        this.gap = gap;
        f2 = f1 + (this.nbFreq - 1) * gap;
        freqs = new double[this.nbFreq];
        for (int i = 0; i < this.nbFreq; i++) {
            freqs[i] = f1 + i * gap;
        }

        initChirp = createChirp(f1 - 2 * gap, f2 + 2 * gap, blockSize);
    }

    public short[] createCode(List<Indices> code, int nb_sec) {
        int nb_char = code.size();
        int presil = blockSize;
        float[] res = new float[targetSampleRate * nb_sec];
        float[] temp;

        for (int i = 0; i < blockSize; i++) {
            res[presil + i] = initChirp[i];
        }
        int count = presil + 2 * blockSize;

        for (int j = 0; j < nb_char; j++) {
            temp = createSin(code.get(j), blockSize);
            for (int i = 0; i < blockSize; i++) {
                res[count] = temp[i];
                count++;
            }
        }

       final short[] audioCode;
        if (nativeSampleRate==targetSampleRate) {
            audioCode = TsUtils.fromFloatToShortArray(res);
        } else {
            float resampleFactor = (float) nativeSampleRate / (float) targetSampleRate;

            Resampler resampler = new Resampler(true, resampleFactor, resampleFactor);
            float[] resampled = new float[(int) (2 * targetSampleRate * resampleFactor)];
            resampler.process(resampleFactor, res, 0, targetSampleRate, true, resampled, 0, (int) (targetSampleRate * resampleFactor));
            audioCode = TsUtils.fromFloatToShortArray(resampled);
        }



        //Timber.d("("+res.get(i-1).getInd1()+","+res.get(i-1).getInd2()+")");
          /*  String blop = ((Thread.currentThread()).toString()).substring(14, 18);//"comp"+ ("0000" + compt).substring((""+compt).length());
            try {
                logText(audioCode, blop);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } // compt++;*/

        return audioCode;
    }

    private float[] createSin(Indices ind, int size) {
        float[] sig;
        float[] env_amplitude = new float[size];
        TsUtils.tukeywin(env_amplitude, size, .25f);
        double phase = 0;
        double amplitude = 0.5d;
        double[] temp = new double[size];
        double f1 = freqs[ind.getInd1()] * 2 * TsUtils.M_PI / (targetSampleRate);
        double f2 = freqs[ind.getInd2()] * 2 * TsUtils.M_PI / (targetSampleRate);
        for (int i = 0; i < size; i++) {
            temp[i] = ((amplitude * java.lang.Math.sin(i * f1)) + (amplitude * java.lang.Math.sin(i * f2))) * env_amplitude[i];
        }
        sig = TsUtils.fromDoubleToFloatArray(temp);
        return sig;
    }

    private float[] createChirp(double freq_1, double freq_2, int size) {
        float[] chirp;
        float[] env_amplitude = new float[size];
        TsUtils.tukeywin(env_amplitude, size, .25f);
        double phase = 0;
        //double amplitude = 0.4d;
        double[] temp = new double[size];
        double low_freq_radians = freq_1 * 2 * TsUtils.M_PI / targetSampleRate;
        double hi_freq_radians = freq_2 * 2 * TsUtils.M_PI / targetSampleRate;
        for (int i = 0; i < size; i++) {
            phase += ((hi_freq_radians - low_freq_radians) / size) * i + low_freq_radians;
            temp[i] = (java.lang.Math.sin(phase)) * env_amplitude[i];
        }
        chirp = TsUtils.fromDoubleToFloatArray(temp);
        return chirp;
    }

}
