package com.stimcom.sdk.common.messages.broadcaster;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.WakefulBroadcastReceiver;

import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.detection.Proximity;
import com.stimcom.sdk.common.messages.Messages;
import com.stimcom.sdk.common.utils.Timber;

/**
 * A base class for the broadcast receiver to be implemented by the end user. Takes care of properly
 * extracting the message information from the intent. User only has to override the functions
 * he is interested about.
 * <p/>
 * Created by Vincent Mimoun-Prat on 30/06/2015.
 */
public class StimComBroadcastReceiver extends WakefulBroadcastReceiver {

    @Override
    public final void onReceive(Context context, Intent intent) {
        final int messageCategory = intent.getIntExtra(AbstractBroadcaster.EXTRA_MESSAGE_CATEGORY, 0);

        switch (messageCategory) {
            case Messages.Category.ERROR:
                onReceiveErrorMessage(context, intent);
                break;

            case Messages.Category.INFO:
                onReceiveInfoMessage(context, intent);
                break;

            case Messages.Category.DETECTION:
                onReceiveDetectionMessage(context, intent);
                break;

            case Messages.Category.DEBUG:
                onReceiveDebugMessage(context, intent);
                break;

            default:
                Timber.e("Message category %d is not handled!", messageCategory);
        }
    }

    /**
     * Process a debug message
     *
     * @param context The context
     * @param intent  The intent with the message
     */
    private void onReceiveDebugMessage(Context context, Intent intent) {
        final String code = intent.getStringExtra(AbstractBroadcaster.EXTRA_MESSAGE_CODE);
        final Bundle data = intent.getBundleExtra(AbstractBroadcaster.EXTRA_MESSAGE_DEBUG_DATA);

        onDebugInformation(context, code, data);
    }

    /**
     * Process a detection message
     *
     * @param context The context
     * @param intent  The intent with the message
     */
    private void onReceiveDetectionMessage(Context context, Intent intent) {
        final int code = intent.getIntExtra(AbstractBroadcaster.EXTRA_MESSAGE_CODE, 0);

        switch (code) {
            case Messages.Detection.SIGNAL_DETECTED:
                final String detectorType = intent.getStringExtra(AbstractBroadcaster.EXTRA_MESSAGE_DETECTOR_TYPE);
                final String signalCode = intent.getStringExtra(AbstractBroadcaster.EXTRA_MESSAGE_SIGNAL_CODE);
                final String proximity = intent.getStringExtra(AbstractBroadcaster.EXTRA_MESSAGE_PROXIMITY);
                onSignalDetected(context,
                        Detector.Type.fromString(detectorType),
                        signalCode,
                        Proximity.fromString(proximity));
                break;

            default:
                Timber.w("Detection message type %d is not handled yet");
        }
    }

    /**
     * Process an info message
     *
     * @param context The context
     * @param intent  The intent with the message
     */
    private void onReceiveInfoMessage(Context context, Intent intent) {
        final int code = intent.getIntExtra(AbstractBroadcaster.EXTRA_MESSAGE_CODE, 0);
        final String details = intent.getStringExtra(AbstractBroadcaster.EXTRA_MESSAGE_DETAILS);

        switch (code) {
            case Messages.Info.STIMCOM_READY:
                onStimComReady(context);
                break;

            case Messages.Info.DETECTION_STARTED:
                onDetectionStarted(context);
                break;

            case Messages.Info.DETECTION_STOPPED:
                onDetectionStopped(context);
                break;

            case Messages.Info.EMISSION_STARTED:
                onEmissionStarted(context);
                break;

            case Messages.Info.EMISSION_STOPPED:
                onEmissionStopped(context);
                break;

            default:
                onGenericInfo(context, code, details);
        }
    }

    /**
     * Process an error message
     *
     * @param context The context
     * @param intent  The intent with the message
     */
    private void onReceiveErrorMessage(Context context, Intent intent) {
        final int code = intent.getIntExtra(AbstractBroadcaster.EXTRA_MESSAGE_CODE, 0);
        final String details = intent.getStringExtra(AbstractBroadcaster.EXTRA_MESSAGE_DETAILS);

        switch (code) {
            default:
                onGenericError(context, code, details);
        }
    }

    /**
     * Called when debug information is available
     *
     * @param context The application context
     * @param code    The debug code
     * @param data    The data linked to the debug information
     */
    @SuppressWarnings("UnusedParameters")
    protected void onDebugInformation(Context context, String code, @Nullable Bundle data) {
    }

    /**
     * Called when an error occurred
     *
     * @param context The application context
     * @param code    The error code
     * @param details The error message
     */
    @SuppressWarnings("UnusedParameters")
    protected void onGenericError(Context context, int code, @Nullable String details) {
    }

    /**
     * Called when an information is available
     *
     * @param context The application context
     * @param code    The information code
     * @param details The information message
     */
    @SuppressWarnings("UnusedParameters")
    protected void onGenericInfo(Context context, int code, @Nullable String details) {
    }

    /**
     * Called when the SDK is ready to be used
     *
     * @param context The application context
     */
    @SuppressWarnings("UnusedParameters")
    protected void onStimComReady(Context context) {
    }

    /**
     * Called when the emission has started
     *
     * @param context The application context
     */
    @SuppressWarnings("UnusedParameters")
    protected void onEmissionStarted(Context context) {
    }

    /**
     * Called when the emission has stopped
     *
     * @param context The application context
     */
    @SuppressWarnings("UnusedParameters")
    protected void onEmissionStopped(Context context) {
    }

    /**
     * Called when the detection has started
     *
     * @param context The application context
     */
    @SuppressWarnings("UnusedParameters")
    protected void onDetectionStarted(Context context) {
    }

    /**
     * Called when the detection has stopped
     *
     * @param context The application context
     */
    @SuppressWarnings("UnusedParameters")
    protected void onDetectionStopped(Context context) {
    }

    /**
     * Called when a signal has been detected
     *
     * @param context      The application context
     * @param detectorType The type of detector
     * @param signalCode   The signal code
     * @param proximity    The proximity of the source of the signal
     */
    @SuppressWarnings("UnusedParameters")
    protected void onSignalDetected(Context context, Detector.Type detectorType, String signalCode, Proximity proximity) {
    }
}
