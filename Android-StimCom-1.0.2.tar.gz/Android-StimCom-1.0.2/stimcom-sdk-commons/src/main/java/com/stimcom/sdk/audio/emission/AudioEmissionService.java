package com.stimcom.sdk.audio.emission;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.IBinder;

import com.google.common.base.Strings;
import com.stimcom.sdk.audio.Constants;
import com.stimcom.sdk.audio.utils.Decoder;
import com.stimcom.sdk.common.StimCom;
import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.emission.AbstractEmissionService;
import com.stimcom.sdk.common.messages.Messages;
import com.stimcom.sdk.common.messages.Messenger;
import com.stimcom.sdk.common.model.Signal;
import com.stimcom.sdk.common.utils.Timber;

/**
 * Service handling audio detection
 */
public class AudioEmissionService extends AbstractEmissionService {

    private static final String EXTRA_SIGNAL_CODE = "com.stimcom.sdk.ExtraSignalCode";

    /**
     * Get the Intent to start or stop this service
     *
     * @param context The context
     * @return The intent
     */
    public static Intent newIntent(Context context, Signal signal) {
        Intent i = new Intent(context, AudioEmissionService.class);
        i.putExtra(EXTRA_SIGNAL_CODE, signal.code);
        return i;
    }

    // region State management

    // Looks hacky to you? Well, me too but here is the source:
    // http://stackoverflow.com/questions/600207/how-to-check-if-a-service-is-running-on-android
    //
    // Looks ok because our services are local.
    public static boolean isRunning = false;

    public static boolean isRunning() {
        return isRunning;
    }

    private static void setIsRunning(boolean isRunning) {
        AudioEmissionService.isRunning = isRunning;
    }

    // endregion

    private SdkConfiguration sdkConfiguration;
    private Messenger messenger;
    private AudioTrack audioTrack = null;
    private String signalCode = "";
    private Thread audioThread = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        StimCom stimCom = StimCom.get();

        if (!stimCom.isReady()) {
            Timber.w("Audio detection service started but StimCom is not ready yet. Bailing.");
            return;
        }

        // Initialize our components
        messenger = stimCom.getMessenger();
        sdkConfiguration = stimCom.getSdkConfiguration();

        setIsRunning(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Get the signal code from our intent
        signalCode = intent.getStringExtra(EXTRA_SIGNAL_CODE);
        if (Strings.isNullOrEmpty(signalCode) || signalCode.length() != Constants.NB_CHAR) {
            messenger.sendOnStimComError(Messages.Error.AUDIO_EMISSION_ERROR,
                    String.format(
                            "The audio emission service expects a signal code with %d characters.",
                            Constants.NB_CHAR));
            return START_NOT_STICKY;
        }

        if (audioThread != null) {
            audioThread.interrupt();
            audioThread = null;
        }

        audioThread = new Thread(emissionRunnable);
        audioThread.run();

        return START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy() {
        if (audioThread != null) {
            audioThread.interrupt();
            audioThread = null;
        }

        if (audioTrack != null) {
            if (audioTrack.getPlayState() != AudioTrack.PLAYSTATE_STOPPED) audioTrack.stop();
            audioTrack.release();
        }

        // Just in case
        audioTrack = null;

        // Ok. we're not in business anymore
        setIsRunning(false);

        super.onDestroy();
    }

    /**
     * Background process to prepare and playback the audio data
     */
    private Runnable emissionRunnable = new Runnable() {
        @Override
        public void run() {
            prepareAudioTrack();

            if (Thread.currentThread().isInterrupted()) {
                audioTrack.release();
                audioTrack = null;
            }

            playAudioTrack();
        }
    };

    /**
     * Compute the audio data and initialize the audio track to playback that data
     */
    private void prepareAudioTrack() {
        // Device's native sample rate
        int nativeSampleRate = AudioTrack.getNativeOutputSampleRate(AudioManager.STREAM_MUSIC);

        // Create the audio data to play back on the audio track
        Decoder encoder = new Decoder(Constants.NB_CHAR, 2);
        AudioCode audioCode = new AudioCode(Constants.BASE_BUFFER_SIZE,
                nativeSampleRate,
                Constants.SAMPLE_RATE,
                Constants.NB_FREQ,
                Constants.F1,
                Constants.GAP);
        final short[] audioSignal = audioCode.createCode(encoder.encode(signalCode), Constants.NB_CRC);

        // Create the audio track and play the audio we just computed
        if (audioTrack != null) {
            if (audioTrack.getPlayState() != AudioTrack.PLAYSTATE_STOPPED) audioTrack.stop();
            audioTrack.release();
            audioTrack = null;
        }

        audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC,
                nativeSampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                Constants.NB_CRC * nativeSampleRate * 2,
                AudioTrack.MODE_STATIC);

        if (Build.VERSION.SDK_INT >= 21) {
            audioTrack.setVolume(0.7f);
        } else {
            //noinspection deprecation
            audioTrack.setStereoVolume(0.7f, 0.7f);
        }

        audioTrack.write(audioSignal, 0, Constants.NB_CRC * nativeSampleRate);
        audioTrack.setLoopPoints(0, Constants.NB_CRC * nativeSampleRate - 1, -1);
    }

    /**
     * Start playing the audio signal
     */
    private void playAudioTrack() {
        switch (audioTrack.getState()) {
            case AudioTrack.STATE_UNINITIALIZED:
                messenger.sendOnStimComError(Messages.Error.AUDIO_EMISSION_ERROR, "Failed to start the audio emission. Audio track not ready: STATE_UNINITIALIZED");
                audioTrack.release();
                audioTrack = null;
                break;

            case AudioTrack.STATE_NO_STATIC_DATA:
                messenger.sendOnStimComError(Messages.Error.AUDIO_EMISSION_ERROR, "Failed to start the audio emission. Audio track not ready: STATE_NO_STATIC_DATA");
                audioTrack.release();
                audioTrack = null;
                break;

            default:
                audioTrack.play();
        }
    }
}
