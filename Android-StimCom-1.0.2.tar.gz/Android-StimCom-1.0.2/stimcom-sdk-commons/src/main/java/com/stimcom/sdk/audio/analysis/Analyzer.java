package com.stimcom.sdk.audio.analysis;

import android.os.Handler;
import android.util.Log;

import com.stimcom.sdk.audio.utils.Indices;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.emory.mathcs.jtransforms.fft.FloatFFT_1D;

/**
 * Created by Romain on 30/09/2015.
 */
public class Analyzer {
    int sizeBlock;
    int sampleRate;
    int nbChar, nbFreq, compt;
    double f1, f2, gap;
    int[] freqs;
    static double[] fftChirpEn = {0.99, //Attention données en dur, dépend des paramètres de chirp
            1.01, // et des plages de féquences
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1.01,
            0.99};
    FloatFFT_1D fft;
    Handler handler;
    Thread analysisThread;

    public Analyzer(int sampleRate, int sizeBlock, int nbChar, double f1, double f2, int nbFreq) {
        super();
        this.sampleRate = sampleRate;
        this.sizeBlock = sizeBlock;
        this.nbChar = nbChar;
        this.f1 = f1;
        this.f2 = f2;
        this.nbFreq = nbFreq;
        fft = new FloatFFT_1D(sizeBlock);
        handler = new Handler();
        this.gap = (f2 - f1) / (nbFreq - 1);
        this.freqs = new int[nbFreq];
        for (int i = 0; i < nbFreq; i++) {
            freqs[i] = (int) (((f1 + i * gap) * sizeBlock) / sampleRate);
        }
        this.compt = 0;
    }

    protected void startAnalysis(float[] data) {
        //Log.d("Analyzer", "start");
        List<Indices> res = new ArrayList<Indices>();
        float[] analDir, analRev, analysis;
        double[] energy = new double[nbFreq];
        double[] baseEn = new double[nbFreq];
        int index;
        analDir = Arrays.copyOf(data, sizeBlock);
        analRev = Arrays.copyOfRange(data, sizeBlock, 2 * sizeBlock);
        String blop = String.format("%04d", compt);
        fft.realForward(analDir);
        fft.realForward(analRev);
        for (int j = 0; j < nbFreq; j++) {
            baseEn[j] = fftChirpEn[j] * Math.sqrt((double) (analDir[2 * freqs[j]] * analDir[2 * freqs[j]] + analDir[2 * freqs[j] + 1] * analDir[2 * freqs[j] + 1])
                    + Math.sqrt((double) (analRev[2 * freqs[j]] * analRev[2 * freqs[j]] + analRev[2 * freqs[j] + 1] * analRev[2 * freqs[j] + 1])));
            //Log.d("dir", ""+analDir[2 * freqs[j]-1] + "+ j*" +analDir[2 * freqs[j]]);
            //Log.d("rev", ""+analRev[2 * freqs[j]-1]+ "+ j*" +analRev[2 * freqs[j]]);
            //Log.d("energy", ""+j+"_"+baseEn[j]);
        }
        //Log.d("energy", "" +baseEn[0] + " ; " +baseEn[1] + " ; "+baseEn[2] + " ; "+baseEn[3] + " ; "+baseEn[4] + " ; "+baseEn[5] + " ; "+baseEn[6] + " ; "+baseEn[7]
        //        + " ; "+baseEn[8]+ " ; "+baseEn[9]+ " ; "+baseEn[10]+ " ; "+baseEn[11]);

        /*try {
            TsUtils.logText(analDir, "direct"+compt);
            TsUtils.logText(analRev, "reverb"+compt);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }//*/

        for (int i = 2; i <= nbChar + 1; i++) {
            index = i * sizeBlock;
            analysis = Arrays.copyOfRange(data, index + 1, index + sizeBlock + 1);
            fft.realForward(analysis);
            //energy[0]=analysis[0];
            for (int j = 0; j < nbFreq; j++) {
                energy[j] = (float) Math.sqrt((double) (analysis[2 * freqs[j]] * analysis[2 * freqs[j]] + analysis[2 * freqs[j] + 1] * analysis[2 * freqs[j] + 1])); //Indices shift due to JTransform FFT structure
                energy[j] /= baseEn[j];
                //Log.d("energy", ""+j+"_"+energy[j]);
            }
            int ind1 = findIndMax(energy);
            int ind2 = findIndMax(energy);
            res.add(new Indices(ind1, ind2));
        }
        List<Indices> comp = new ArrayList<Indices>();
        comp.add(new Indices(7, 11));
        comp.add(new Indices(6, 7));
        comp.add(new Indices(4, 5));
        comp.add(new Indices(1, 4));
        comp.add(new Indices(0, 6));
        comp.add(new Indices(2, 3));
        comp.add(new Indices(4, 7));
        comp.add(new Indices(0, 7));

        Log.d("Analysis", "(" + res.get(0).getInd1() + "," + res.get(0).getInd2() + ") ; "
                + "(" + res.get(1).getInd1() + "," + res.get(1).getInd2() + ") ; "
                + "(" + res.get(2).getInd1() + "," + res.get(2).getInd2() + ") ; "
                + "(" + res.get(3).getInd1() + "," + res.get(3).getInd2() + ") ; "
                + "(" + res.get(4).getInd1() + "," + res.get(4).getInd2() + ") ; "
                + "(" + res.get(5).getInd1() + "," + res.get(5).getInd2() + ") ; "
                + "(" + res.get(6).getInd1() + "," + res.get(6).getInd2() + ") ; "
                + "(" + res.get(7).getInd1() + "," + res.get(7).getInd2() + ") ; ");
        //if(comp.equals(res)){

        //Log.d("Analysis",blop);


           /* try {
                TsUtils.logText(data, blop);
                compt++;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }//

        //}*/
        //Log.d("Detection", "Analyzed");
        notifyListener(res);

    }

    private int findIndMax(double[] data) {
        int n = data.length;
        int ind = 0;
        double max = 0f;
        for (int i = 0; i < n; i++) {
            if (data[i] > max) {
                max = data[i];
                ind = i;
            }
        }
        data[ind] = 0;
        return ind;
    }

    private SignalAnalyzedListener mListener = null;

    public void setListener(SignalAnalyzedListener l) {
        mListener = l;
    }

    /**
     * notify listener with sanity check
     *
     * @param s
     */
    private void notifyListener(List<Indices> s) {
        if (mListener != null) {
            mListener.onSignalAnalyzed(s);
        }
    }

    public void onSignalReceived(float[] recorded) {

        // We make a copy to avoid concurrent thread modification.
        // Make a copy and pad with 0s at size_fft
        final float[] analyseBuffer = Arrays.copyOf(recorded, (nbChar + 4) * sizeBlock);
        // // Define job
        Runnable analysisRun = new Runnable() {
            @Override
            public void run() {
                startAnalysis(analyseBuffer);
            }
        };

        analysisThread = new Thread(analysisRun);
        analysisThread.start();

    }

}
