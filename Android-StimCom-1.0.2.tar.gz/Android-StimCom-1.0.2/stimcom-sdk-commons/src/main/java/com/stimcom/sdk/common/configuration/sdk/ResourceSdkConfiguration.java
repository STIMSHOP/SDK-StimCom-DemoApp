package com.stimcom.sdk.common.configuration.sdk;

import android.content.Context;
import android.content.res.Resources;

import com.google.common.collect.Sets;
import com.stimcom.sdk.common.configuration.InvalidConfigurationException;
import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.messages.Messenger;

import java.util.Set;

/**
 * Implementation to read the configuration from application resources (ex. the values/stimcom.xml file)
 * <p/>
 * Created by vprat on 01/07/2015.
 */
public class ResourceSdkConfiguration implements SdkConfiguration {

    private Messenger.Type messengerType = Messenger.Type.LOCAL_BROADCASTER;
    private Set<Detector.Type> requestedDetectorTypes;
    private Set<Emitter.Type> requestedEmitterTypes;

    /**
     * Create a resource configuration using a context
     *
     * @param context The application context
     * @return An instance of ResourceConfiguration with the proper configuration values
     * @throws InvalidConfigurationException If anything went wrong
     */
    public static SdkConfiguration createFromResources(Context context)
            throws InvalidConfigurationException {
        ResourceSdkConfiguration conf = new ResourceSdkConfiguration();

        String appPackageName = context.getPackageName();
        Resources resources = context.getResources();

        // Required
        conf.requestedDetectorTypes = fetchRequestedDetectorTypes(resources, appPackageName);
        conf.requestedEmitterTypes = fetchRequestedEmitterTypes(resources, appPackageName);

        // Optional
        conf.messengerType = fetchMessengerType(resources, appPackageName);

        return conf;
    }

    @Override
    public Set<Detector.Type> getRequestedDetectorTypes() {
        return requestedDetectorTypes;
    }

    @Override
    public Set<Emitter.Type> getRequestedEmitterTypes() {
        return requestedEmitterTypes;
    }

    @Override
    public Messenger.Type getMessengerType() {
        return messengerType;
    }

    /**
     * Make use of {@link ResourceSdkConfiguration#createFromResources(Context)} method to build an
     * object of this kind
     */
    protected ResourceSdkConfiguration() {
    }

    /**
     * Get that configuration value from the resources
     *
     * @param resources      The resources
     * @param appPackageName The end-user application package name
     * @return The configuration value
     */
    private static Messenger.Type fetchMessengerType(Resources resources, String appPackageName) {
        try {
            int resId = resources.getIdentifier("stimcom_messenger", "string", appPackageName);
            String id = resources.getString(resId);
            if (id.length() == 0) {
                id = Messenger.Type.LOCAL_BROADCASTER.name();
            }

            return Messenger.Type.fromString(id);
        } catch (IllegalArgumentException e) {
            throw new InvalidConfigurationException(e.getMessage());
        } catch (Exception e) {
            return Messenger.Type.LOCAL_BROADCASTER;
        }
    }

    /**
     * Get that configuration value from the resources
     *
     * @param resources      The resources
     * @param appPackageName The end-user application package name
     * @return The configuration value
     * @throws InvalidConfigurationException if the value is missing
     */
    private static Set<Detector.Type> fetchRequestedDetectorTypes(Resources resources, String appPackageName)
            throws InvalidConfigurationException {
        try {
            int resId = resources.getIdentifier("stimcom_detectors", "array", appPackageName);
            String[] ids = resources.getStringArray(resId);
            if (ids == null || ids.length == 0) {
                throw new InvalidConfigurationException("stimcom_detectors is required");
            }

            Set<Detector.Type> types = Sets.newHashSet();
            for (String typeId : ids) {
                Detector.Type t = Detector.Type.fromString(typeId);
                types.add(t);
            }
            return types;
        } catch (IllegalArgumentException e) {
            throw new InvalidConfigurationException(e.getMessage());
        } catch (Exception e) {
            throw new InvalidConfigurationException("stimcom_detectors is required");
        }
    }

    /**
     * Get that configuration value from the resources
     *
     * @param resources      The resources
     * @param appPackageName The end-user application package name
     * @return The configuration value
     * @throws InvalidConfigurationException if the value is missing
     */
    private static Set<Emitter.Type> fetchRequestedEmitterTypes(Resources resources, String appPackageName)
            throws InvalidConfigurationException {
        try {
            int resId = resources.getIdentifier("stimcom_emitters", "array", appPackageName);
            String[] ids = resources.getStringArray(resId);
            if (ids == null || ids.length == 0) {
                throw new InvalidConfigurationException("stimcom_emitters is required");
            }

            Set<Emitter.Type> types = Sets.newHashSet();
            for (String typeId : ids) {
                Emitter.Type t = Emitter.Type.fromString(typeId);
                types.add(t);
            }
            return types;
        } catch (IllegalArgumentException e) {
            throw new InvalidConfigurationException(e.getMessage());
        } catch (Exception e) {
            throw new InvalidConfigurationException("stimcom_emitters is required");
        }
    }
}
