package com.stimcom.sdk.audio.utils;

public class MaxValIndexDouble {
    public double max = 0.0;
    public int index = 0;


}