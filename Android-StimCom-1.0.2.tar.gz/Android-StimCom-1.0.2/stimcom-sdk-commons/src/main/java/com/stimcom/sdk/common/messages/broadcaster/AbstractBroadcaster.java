package com.stimcom.sdk.common.messages.broadcaster;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.detection.Proximity;
import com.stimcom.sdk.common.messages.Messages;
import com.stimcom.sdk.common.messages.Messenger;
import com.stimcom.sdk.common.model.Signal;

/**
 * Base class for broadcasters (implementation of the Messenger interface using Android's broadcasting system)
 * <p/>
 * Created by vprat on 03/12/2015.
 */
public abstract class AbstractBroadcaster implements Messenger {

    // The intent action for all our general broadcasts
    public static final String ACTION_RECEIVE_MESSAGES = "com.stimcom.sdk.action.RECEIVE_MESSAGES";

    // The code associated to the message
    static final String EXTRA_MESSAGE_CATEGORY = "com.stimcom.sdk.message.Category";

    // The code associated to the message
    static final String EXTRA_MESSAGE_CODE = "com.stimcom.sdk.message.Code";

    // The code associated to the message
    static final String EXTRA_MESSAGE_DETAILS = "com.stimcom.sdk.message.Error";

    // The type of detector
    static final String EXTRA_MESSAGE_DETECTOR_TYPE = "com.stimcom.sdk.message.DetectorType";

    // The proximity
    static final String EXTRA_MESSAGE_PROXIMITY = "com.stimcom.sdk.message.Proximity";

    // The code of the signal
    static final String EXTRA_MESSAGE_SIGNAL_CODE = "com.stimcom.sdk.message.SignalCode";

    // Additional data to debug messages
    static final String EXTRA_MESSAGE_DEBUG_DATA = "com.stimcom.sdk.message.DebugData";

    // The application context
    protected final Context context;

    /**
     * Constructor
     *
     * @param context The application context
     */
    public AbstractBroadcaster(Context context) {
        this.context = context;
    }

    @Override
    public void sendOnStimComReady() {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.INFO)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Info.STIMCOM_READY));
    }

    @Override
    public void sendOnDetectionStarted() {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.INFO)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Info.DETECTION_STARTED)
                .putExtra(EXTRA_MESSAGE_DETAILS, "Detection started"));
    }

    @Override
    public void sendOnDetectionStopped() {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.INFO)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Info.DETECTION_STOPPED)
                .putExtra(EXTRA_MESSAGE_DETAILS, "Detection stopped"));
    }

    @Override
    public void sendOnEmissionStarted() {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.INFO)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Info.EMISSION_STARTED)
                .putExtra(EXTRA_MESSAGE_DETAILS, "Emission started"));
    }

    @Override
    public void sendOnEmissionStopped() {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.INFO)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Info.EMISSION_STOPPED)
                .putExtra(EXTRA_MESSAGE_DETAILS, "Emission stopped"));
    }

    @Override
    public void sendOnStimComError(int errorCode, @Nullable String errorMessage) {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.ERROR)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Info.STIMCOM_READY)
                .putExtra(EXTRA_MESSAGE_DETAILS, errorMessage));
    }

    @Override
    public void sendOnSignalDetected(Detector.Type detectorType, Signal signal, Proximity proximity) {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.DETECTION)
                .putExtra(EXTRA_MESSAGE_CODE, Messages.Detection.SIGNAL_DETECTED)
                .putExtra(EXTRA_MESSAGE_DETECTOR_TYPE, detectorType.name())
                .putExtra(EXTRA_MESSAGE_PROXIMITY, proximity.name())
                .putExtra(EXTRA_MESSAGE_SIGNAL_CODE, signal.code));
    }

    @Override
    public void sendOnDebugInformation(String code, Bundle data) {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.DEBUG)
                .putExtra(EXTRA_MESSAGE_CODE, code)
                .putExtra(EXTRA_MESSAGE_DEBUG_DATA, data));
    }

    @Override
    public void sendOnDebugInformation(String code) {
        sendPrivateBroadcast(new Intent(ACTION_RECEIVE_MESSAGES)
                .putExtra(EXTRA_MESSAGE_CATEGORY, Messages.Category.DEBUG)
                .putExtra(EXTRA_MESSAGE_CODE, code));
    }

    /**
     * Child subclasses should implement this method to actually send the broadcast intent
     *
     * @param broadcast The intent to send
     */
    protected abstract void sendPrivateBroadcast(Intent broadcast);
}
