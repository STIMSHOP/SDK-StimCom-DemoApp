package com.stimcom.sdk.audio.utils;

import edu.emory.mathcs.jtransforms.fft.FloatFFT_1D;

/**
 * This class has been introduced to avoid
 * s
 *
 * @author vincent
 */
public class Convolution {

    // FFTS fftsForward, fftsBackward;

    FloatFFT_1D fft;

    int sizeFft;
    int sampleRate;

    public int getSizeFft() {
        return sizeFft;

    }

    public void setSizeFft(int sizeFft) {
        this.sizeFft = sizeFft;
    }

    public Convolution(int sizeFft, int sampleRate) {

        super();
        this.sampleRate = sampleRate;
        this.sizeFft = sizeFft;
        fft = new FloatFFT_1D(sizeFft);

    }

    public void fft_conv(float[] data, float[] upF, float[] dwF, float[] y_up,
                         float[] y_dw) {

        fft.realForward(data);
        int f_lim = 16000;
        int ind_start = 2 * f_lim * sizeFft / sampleRate;
        if (ind_start % 2 == 1) {
            ind_start -= 1;
        }

        for (int k = ind_start; k < sizeFft; k++) {

            y_up[k] = data[k] * upF[k] - data[k + 1] * upF[k + 1];
            y_dw[k] = data[k] * dwF[k] - data[k + 1] * dwF[k + 1];
            k++;
            y_up[k] = data[k - 1] * upF[k] + data[k] * upF[k - 1];
            y_dw[k] = data[k - 1] * dwF[k] + data[k] * dwF[k - 1];
        }
        fft.realInverse(y_up, false);
        fft.realInverse(y_dw, false);

    }

    public void fft_conv(float[] data, float[] upF, float[] y_up) {

        fft.realForward(data);
        int f_lim = 16000;
        int ind_start = 2 * f_lim * sizeFft / sampleRate;
        if (ind_start % 2 == 1) {
            ind_start -= 1;
        }

        for (int k = ind_start; k < sizeFft; k++) {
            y_up[k] = data[k] * upF[k] - data[k + 1] * upF[k + 1];

            k++;
            y_up[k] = data[k - 1] * upF[k] + data[k] * upF[k - 1];

        }
        fft.realInverse(y_up, false);


    }

}
