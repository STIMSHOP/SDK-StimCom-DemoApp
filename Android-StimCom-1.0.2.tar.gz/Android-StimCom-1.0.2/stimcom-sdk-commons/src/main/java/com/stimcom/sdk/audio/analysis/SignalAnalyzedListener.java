package com.stimcom.sdk.audio.analysis;


import com.stimcom.sdk.audio.utils.Indices;

import java.util.List;

/**
 * Created by Romain on 30/09/2015.
 */
public interface SignalAnalyzedListener {

    /**
     * Tiggered when signal ahas been detected and analyzed
     *
     * @param analyzed
     */
    void onSignalAnalyzed(List<Indices> analyzed);


    void onSignalAnalyzisError();

}