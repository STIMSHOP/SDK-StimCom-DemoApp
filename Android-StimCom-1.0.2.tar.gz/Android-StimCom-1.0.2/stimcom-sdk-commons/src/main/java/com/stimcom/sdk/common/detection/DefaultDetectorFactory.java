package com.stimcom.sdk.common.detection;

import android.content.Context;

import com.google.common.collect.Maps;
import com.stimcom.sdk.audio.detection.AudioDetector;
import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.messages.Messenger;

import java.util.Map;

/**
 * A default implementation for the factory of signal detectors
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public class DefaultDetectorFactory implements DetectorFactory {

    private Context context;
    private Messenger messenger;

    public DefaultDetectorFactory(Context context, Messenger messenger) {
        this.context = context;
        this.messenger = messenger;
    }

    @Override
    public Map<Detector.Type, Detector> createFromConfiguration(SdkConfiguration sdkConfiguration) {
        Map<Detector.Type, Detector> detectors = Maps.newHashMap();

        for (Detector.Type type : sdkConfiguration.getRequestedDetectorTypes()) {
            detectors.put(type, create(type, sdkConfiguration));
        }

        return detectors;
    }

    @Override
    public Detector create(Detector.Type type, SdkConfiguration sdkConfiguration) {
        switch (type) {
            case AUDIO:
                return new AudioDetector(context);
        }

        throw new RuntimeException("Unsupported detector type");
    }

}
