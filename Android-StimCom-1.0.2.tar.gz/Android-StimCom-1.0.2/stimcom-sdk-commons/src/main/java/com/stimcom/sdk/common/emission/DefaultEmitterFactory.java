package com.stimcom.sdk.common.emission;

import android.content.Context;

import com.google.common.collect.Maps;
import com.stimcom.sdk.audio.emission.AudioEmitter;
import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.messages.Messenger;

import java.util.Map;

/**
 * A default implementation for the factory of signal emitters
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public class DefaultEmitterFactory implements EmitterFactory {

    private Context context;
    private Messenger messenger;

    public DefaultEmitterFactory(Context context, Messenger messenger) {
        this.context = context;
        this.messenger = messenger;
    }

    @Override
    public Map<Emitter.Type, Emitter> createFromConfiguration(SdkConfiguration sdkConfiguration) {
        Map<Emitter.Type, Emitter> emitters = Maps.newHashMap();

        for (Emitter.Type type : sdkConfiguration.getRequestedEmitterTypes()) {
            emitters.put(type, create(type, sdkConfiguration));
        }

        return emitters;
    }

    @Override
    public Emitter create(Emitter.Type type, SdkConfiguration sdkConfiguration) {
        switch (type) {
            case AUDIO:
                return new AudioEmitter(context);
        }

        throw new RuntimeException("Unsupported detector type");
    }

}
