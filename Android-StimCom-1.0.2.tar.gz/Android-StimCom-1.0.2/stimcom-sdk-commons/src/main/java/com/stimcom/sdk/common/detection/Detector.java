package com.stimcom.sdk.common.detection;

/**
 * The contract for objects which detect a signal
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public interface Detector {

    /**
     * The known types of detectors
     */
    enum Type {
        AUDIO,
        BLUETOOTH_LE;

        /**
         * Get the type from a string
         *
         * @param typeId The string representation of the type (case-insensitive)
         * @return The type
         * @throws IllegalArgumentException If the type cannot be found
         */
        public static Type fromString(String typeId) {
            for (Type t : Type.values()) {
                if (t.name().equalsIgnoreCase(typeId)) {
                    return t;
                }
            }
            throw new IllegalArgumentException(typeId + " is not a valid Detector.Type");
        }
    }

    /**
     * Get the type of detector
     *
     * @return A type (audio, bluetooth LE, etc.)
     */
    Type getType();

    /**
     * Indicate if the detector is currently trying to detect signals
     *
     * @return
     */
    boolean isDetecting();

    /**
     * Start detection
     */
    void start();

    /**
     * Stop detection
     */
    void stop();

    /**
     * Is the detector ready for detection?
     *
     * @return true if the detector is ready to be used
     */
    boolean isReady();

    /**
     * Is the detector supported on the current device?
     *
     * @return true if the detector can actually be used
     */
    boolean isSupported();

    /**
     * Enable or disable the power saving mode on the detector. Some detectors can provide significant battery saving
     * when in power saving mode with added latency in the detection for example.
     *
     * Applications can take advantage of this for example by enabling power save mode when performing detection in
     * background.
     *
     * @param isEnabled true to enable power save mode (By default, this mode is disabled)
     */
    // TODO void enablePowerSaving(boolean isEnabled);
}
