package com.stimcom.sdk.audio.utils;

public class MaxValIndexFloat {
    public float max = 0f;
    public int index = 0;


}