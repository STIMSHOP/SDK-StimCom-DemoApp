package com.stimcom.sdk.audio.analysis;

/**
 * Created by Romain on 30/09/2015.
 */
public interface StartDetectedListener {

    /**
     * Triggered when signal has been detected and when
     * full message has been received.
     *
     * @param recorded :  buffer containing the full message received.
     */
    public void onSignalReceived(float[] recorded);

}