package com.stimcom.sdk.common;

import android.content.Context;
import android.support.annotation.Nullable;

import com.google.common.collect.Maps;
import com.stimcom.sdk.common.configuration.sdk.ResourceSdkConfiguration;
import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.initializer.Initializer;
import com.stimcom.sdk.common.initializer.base.BaseInitializer;
import com.stimcom.sdk.common.messages.DefaultMessengerFactory;
import com.stimcom.sdk.common.messages.Messenger;
import com.stimcom.sdk.common.messages.MessengerFactory;
import com.stimcom.sdk.common.model.Signal;
import com.stimcom.sdk.common.utils.Timber;
import com.stimcom.sdk.commons.BuildConfig;

import java.util.Map;

/**
 * The central class for the StimShop SDK
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public final class StimCom {

    // region Main facade setup

    /**
     * The single instance of this class
     */
    private static StimCom singleInstance = null;

    /**
     * This all starts with this function. Use this to setup the SDK in your application class. This will look like:
     * <p/>
     * <pre><code>
     *  StimCom
     *      .create(this)
     *      .withConfiguration(...) // Optional
     *      .start();
     * </code></pre>
     *
     * @param context The application context
     * @return A class which will help you configure the SDK
     */
    public static Bootstrap create(Context context) {
        return new Bootstrap(context.getApplicationContext());
    }

    /**
     * Class used to configure the StimShop instance
     */
    public static class Bootstrap {

        private Context context;
        private SdkConfiguration sdkConfiguration;
        private boolean isDebugEnabled;

        /**
         * Build the bootstrap
         *
         * @param context The application context
         */
        public Bootstrap(Context context) {
            this.context = context;
            this.isDebugEnabled = false;
        }

        /**
         * Provide the SDK configuration.
         *
         * @param sdkConfiguration The configuration
         * @return The bootstrap instance to chain calls
         */
        public Bootstrap withConfiguration(SdkConfiguration sdkConfiguration) {
            this.sdkConfiguration = sdkConfiguration;
            return this;
        }

        /**
         * Provide the SDK configuration.
         *
         * @param enabled True to enable debugging information (logs, etc.)
         * @return The bootstrap instance to chain calls
         */
        public Bootstrap enableDebug(boolean enabled) {
            this.isDebugEnabled = enabled;
            return this;
        }

        /**
         * Call this method last to start the StimCom SDK
         *
         * @return The StimCom instance if you want to use it now. Else you can get it later with {@link StimCom#get()}
         */
        public StimCom start() {
            if (sdkConfiguration == null) {
                sdkConfiguration = ResourceSdkConfiguration.createFromResources(context);
            }

            // Messenger can be configured
            MessengerFactory messengerFactory = new DefaultMessengerFactory(context);
            Messenger messenger = messengerFactory.newMessenger(sdkConfiguration.getMessengerType());

            // Default implementations are provided.
            Initializer initializer = new BaseInitializer(context, sdkConfiguration, messenger);

            singleInstance = new StimCom(context, sdkConfiguration, isDebugEnabled, initializer, messenger);
            return singleInstance;
        }
    }

    /**
     * Access the stimcom SDK. This function cannot be called before you have called {@link StimCom#create(Context)}
     *
     * @return The StimCom instance
     */
    public static StimCom get() {
        if (singleInstance == null) throw new RuntimeException("StimCom has not been configured");
        return singleInstance;
    }

    // endregion

    // Application context
    private Context context;

    // Configuration for the SDK
    private SdkConfiguration sdkConfiguration;

    // The detectors required by the user
    private Map<Detector.Type, Detector> detectors;

    // The emitters required by the user
    private Map<Emitter.Type, Emitter> emitters;

    // The initializer
    private Initializer initializer;

    // Is the SDK ready to be used
    private boolean isReady;

    // Do we enable debugging information
    private boolean isDebugEnabled;

    // The class which sends our messages
    private Messenger messenger;

    /**
     * Constructor is hidden, use the {@link StimCom#create(Context)} and {@link StimCom#get()} methods
     *
     * @param context          Application context
     * @param sdkConfiguration Configuration for the SDK
     * @param isDebugEnabled   Enable debugging information
     * @param initializer      The initializer to use to setup the SDK. Ideally should be injected with DI.
     * @param messenger        The object sending our messages
     */
    private StimCom(Context context,
                    SdkConfiguration sdkConfiguration,
                    boolean isDebugEnabled,
                    Initializer initializer,
                    Messenger messenger) {
        this.context = context;
        this.sdkConfiguration = sdkConfiguration;
        this.isDebugEnabled = isDebugEnabled;
        this.initializer = initializer;
        this.messenger = messenger;
        this.detectors = Maps.newHashMapWithExpectedSize(0);
        this.emitters = Maps.newHashMapWithExpectedSize(0);

        // This is a good place to setup debugging as this is supposed to be the earliest method called in the SDK
        // lifecycle AND supposed to be called only once.
        if (BuildConfig.DEBUG || isDebugEnabled) {
            Timber.plant(new Timber.DebugTree());
        }

        restart();
    }

    /**
     * If the SDK could not be initialized earlier (for example, no network was available at that time), you can call
     * this function to restart the SDK initialization process.
     */
    public void restart() {
        this.isReady = false;

        // Initialize the SDK
        initializer.run(initializerCallback);
    }

    /**
     * Get the current configuration for the SDK
     *
     * @return The configuration
     */
    public SdkConfiguration getSdkConfiguration() {
        return sdkConfiguration;
    }

    /**
     * Is debugging information enabled?
     *
     * @return true if it is enabled
     */
    public boolean isDebugEnabled() {
        return isDebugEnabled;
    }

    /**
     * Get the class responsible for sending our messages
     *
     * @return The messenger
     */
    public Messenger getMessenger() {
        return messenger;
    }

    /**
     * Is the SDK ready to be used?
     *
     * @return true if it is
     */
    public boolean isReady() {
        return isReady;
    }

    /**
     * Start the detection on all the detectors we have
     */
    public void startDetection() {
        messenger.sendOnDetectionStarted();
        for (Detector d : detectors.values()) {
            if (d.isReady()) d.start();
        }
    }

    /**
     * Stop the detection on all the detectors we have
     */
    public void stopDetection() {
        for (Detector d : detectors.values()) {
            d.stop();
        }
        messenger.sendOnDetectionStopped();
    }

    /**
     * Tell if one of the detectors is currently trying to detect signals
     *
     * @return true if detecting
     */
    public boolean isDetecting() {
        for (Detector d : detectors.values()) {
            if (d.isDetecting()) return true;
        }
        return false;
    }

    /**
     * Start the detection on all the detectors we have
     */
    public void startEmission(Signal signal) {
        messenger.sendOnEmissionStarted();
        for (Emitter emitter : emitters.values()) {
            if (emitter.isReady()) emitter.start(signal);
        }
    }

    /**
     * Stop the detection on all the detectors we have
     */
    public void stopEmission() {
        for (Emitter emitter : emitters.values()) {
            emitter.stop();
        }
        messenger.sendOnEmissionStopped();
    }

    /**
     * Tell if one of the detectors is currently trying to detect signals
     *
     * @return true if detecting
     */
    public boolean isEmitting() {
        for (Emitter emitter : emitters.values()) {
            if (emitter.isEmitting()) return true;
        }
        return false;
    }

    /**
     * Enable or disable the power saving mode on the detectors. Some detectors can provide significant battery saving
     * when in power saving mode with added latency in the detection for example.
     *
     * Applications can take advantage of this for example by enabling power save mode when performing detection in
     * background.
     *
     * @param isEnabled true to enable power save mode (By default, this mode is disabled)
     */
    public void enablePowerSaving(boolean isEnabled) {
        for (Detector d : detectors.values()) {
            // TODO Enable power saving mode
            // d.enablePowerSaving(isEnabled);
        }
    }

    /**
     * The callback for the initializer
     */
    @SuppressWarnings("FieldCanBeLocal")
    private Initializer.Callback initializerCallback = new Initializer.Callback() {

        @Override
        public void onEmittersReady(Map<Emitter.Type, Emitter> emitters) {
            StimCom.this.emitters = emitters;
        }

        @Override
        public void onDetectorsReady(Map<Detector.Type, Detector> detectors) {
            StimCom.this.detectors = detectors;
        }

        @Override
        public void onFinished(boolean success) {
            StimCom.this.isReady = success;
            if (success) {
                messenger.sendOnStimComReady();
            }
        }

        @Override
        public void onError(int errorCode, @Nullable String errorMessage) {
            messenger.sendOnStimComError(errorCode, errorMessage);
        }
    };
}
