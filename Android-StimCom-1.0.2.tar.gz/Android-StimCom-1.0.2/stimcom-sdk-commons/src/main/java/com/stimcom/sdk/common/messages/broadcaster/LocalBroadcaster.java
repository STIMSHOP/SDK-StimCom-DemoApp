package com.stimcom.sdk.common.messages.broadcaster;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;

/**
 * Class which allows sending our messages using the Android support library's local broadcast
 * manager. This is safer and more efficient than the system-wide broadcasting system if you don't
 * plan to let other applications access your messages.
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public class LocalBroadcaster extends AbstractBroadcaster {

    // The permission to require on receivers to protect our messages from other apps
    private final LocalBroadcastManager broadcastManager;

    /**
     * Constructor
     *
     * @param context The application context
     */
    public LocalBroadcaster(Context context) {
        super(context);
        broadcastManager = LocalBroadcastManager.getInstance(context);
    }

    /**
     * Send a broadcast with the required permission
     *
     * @param broadcast The broadcast to send
     */
    @Override
    protected void sendPrivateBroadcast(Intent broadcast) {
        broadcastManager.sendBroadcast(broadcast);
    }
}
