package com.stimcom.sdk.common.detection;

import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;

import java.util.Map;

/**
 * The contract for the factory to create objects which detect signals
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public interface DetectorFactory {

    /**
     * Create all detectors which are enabled in the given configuration
     *
     * @param sdkConfiguration The SDK configuration
     * @return A map of detector instances indexed by type
     */
    Map<Detector.Type, Detector> createFromConfiguration(SdkConfiguration sdkConfiguration);

    /**
     * Create a detector given its type
     *
     * @param type             The type of detector we need
     * @param sdkConfiguration The SDK configuration
     * @return A proper implementation for the required detector type
     */
    Detector create(Detector.Type type, SdkConfiguration sdkConfiguration);

}
