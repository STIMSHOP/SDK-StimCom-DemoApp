package com.stimcom.sdk.audio.analysis;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.stimcom.sdk.audio.utils.Convolution;
import com.stimcom.sdk.audio.utils.MaxValIndexFloat;
import com.stimcom.sdk.audio.utils.StimBuffer;
import com.stimcom.sdk.audio.utils.TsUtils;

import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import edu.emory.mathcs.jtransforms.fft.FloatFFT_1D;

/**
 * Created by Romain on 30/09/2015.
 */
public class StartDetector {

    int sampleRate;
    int channelConfiguration = AudioFormat.CHANNEL_IN_MONO;
    int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
    int nbBuffersForStartDetection = 4;
    int nbBuffersShift = 2;
    int fifoBufferSize = 14;
    float recouvParam = (2 * (nbBuffersForStartDetection - nbBuffersShift) / ((float) nbBuffersForStartDetection));
    float threshKurt = 40;
    float threshMax = 1000;
    double f1;
    double f2;

    Queue<StimBuffer> bufferFIFO;

    float[] analyseSounds, startChirpFourrier, startChirpTemporal;
    Convolution fftConvoluer;
    protected int lChirp;
    Thread thread;
    Handler handler;

    int blockSize = 0;
    int nbBuffers;
    RecordAudio recordTask = null;
    int waitingCounter = 0;
    int counter = nbBuffersShift;

    int sizeFft = 2;
    int diff;
    int numSamplesAna = 0;
    int compt = 0;
    float[] analyseBuffer, recouvBuffer, ponderation;
    FloatFFT_1D fft;

    public StartDetector(int sampleRate, int nbBuffers, int baseBufferSize, double f1, double f2) {

        super();
        this.sampleRate = sampleRate;
        this.blockSize = baseBufferSize;
        this.nbBuffers = nbBuffers;
        this.lChirp = baseBufferSize;
        this.f1 = f1;
        this.f2 = f2;
        numSamplesAna = nbBuffersForStartDetection * baseBufferSize;
        while (sizeFft < numSamplesAna) {
            sizeFft *= 2;
        }

        diff = (int) (sizeFft - (recouvParam * sizeFft) / 2);

        // init utils
        fft = new FloatFFT_1D(sizeFft);
        fftConvoluer = new Convolution(sizeFft, sampleRate);

        // init Tables
        startChirpTemporal = new float[lChirp];
        startChirpFourrier = new float[sizeFft];
        analyseBuffer = new float[sizeFft];
        recouvBuffer = new float[sizeFft - diff];
        ponderation = new float[sizeFft];
        TsUtils.tukeywin(ponderation, sizeFft, recouvParam);
        // create the Fourier transform of the signal to convolve with
        createChirp();


        analyseSounds = new float[fifoBufferSize * blockSize];
        thread = new Thread();
        handler = new Handler();

        // Fifo of StimBuffer
        // We us a LinkedBlokingQueue (thread safe) to implement the queue
        bufferFIFO = new LinkedBlockingQueue<>(fifoBufferSize);

        // We fulfill the FIFO
        for (int i = 0; i < fifoBufferSize; i++) {
            StimBuffer toAdd = new StimBuffer(blockSize);
            bufferFIFO.add(toAdd);
        }
        recordTask = new RecordAudio();
    }


    private class RecordAudio extends AsyncTask<Void, float[], Void> {

        @Override
        protected Void doInBackground(Void... params) {

            if (isCancelled()) {
                return null;
            }

            // Some Audio init to record from MicroPhone
            int bufferSize = AudioRecord.getMinBufferSize(sampleRate,
                    channelConfiguration, audioEncoding);

            AudioRecord audioRecord = new AudioRecord(
                    MediaRecorder.AudioSource.DEFAULT, sampleRate,
                    channelConfiguration, audioEncoding, 10 * bufferSize);

            AcousticEchoCanceler.create(audioRecord.getAudioSessionId());
            // Buffer used to read data chunks
            final short[] buffer = new short[blockSize];

            try {
                audioRecord.startRecording();
            } catch (IllegalStateException e) {
                Log.d("StartDetection", "Recording failed " + e.toString());
                return null;
            }
            int compt = 1;
            // Computation loop
            // broken when cancel is called on AsyncTask
            while (audioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                if (isCancelled()) {
                    audioRecord.release();
                    break;
                }

                int bufferReadResult;
                // read blockSize audio data into buffer
                bufferReadResult = audioRecord.read(buffer, 0, blockSize);


                if (bufferReadResult == buffer.length) { // Just a small check to be sure nothing goes wrong.
                    // Get the least recent (the oldest) StimBuffer inserted in FIFO. (object is removed from FIFO)
                    StimBuffer currBuffer = bufferFIFO.poll();

                    // reset with current audio data
                    currBuffer.setBuffer(buffer);


                    // Add the stimBuffer in FIFO
                    bufferFIFO.add(currBuffer);
                    counter--;


                    // startdetector
                    if (counter == 0) {
                        //log("paquet analyse");
                        getBuffersInAnalysisBuffers();
                        Thread channelThread = thread;
                        if (waitingCounter < 0 && !channelThread.isAlive()) {
                            final float[] bufferFloat = Arrays.copyOfRange(analyseSounds, blockSize, nbBuffersForStartDetection * blockSize);
                            // Define job
                            Runnable analysis = new Runnable() {
                                @Override
                                public void run() {
                                    signalDetection(bufferFloat);
                                }
                            };

                            // Post job to handler
                            channelThread = new Thread(analysis);
                            channelThread.start();
                        }

                        counter = nbBuffersShift;
                    }
                    waitingCounter--;
                }
            }
            try {
                audioRecord.stop();
            } catch (IllegalStateException e) {
                Log.d("StartDetection", "Stop failed " + e.toString());
            }
            return null;
        }
    }

    private void getBuffersInAnalysisBuffers() {
        StimBuffer[] buffers = new StimBuffer[fifoBufferSize];
        bufferFIFO.toArray(buffers);
        float[] analysisBuffer = analyseSounds;
        FloatBuffer bigBuffer = FloatBuffer.wrap(analysisBuffer);
        for (StimBuffer tempbuffer : buffers) {
            bigBuffer.put(tempbuffer.getBuffer());
        }
    }

    private void signalDetection(float[] recordedSound) {

        // We make a copy to avoid concurrent thread modification.
        // Copy data into analyseBuffer
        analyseBuffer = Arrays.copyOf(recordedSound, sizeFft);

        // Make convolution
        float[] resConvolution = new float[sizeFft];
        float[] teagerConvolution = new float[sizeFft];
        fftConvoluer.fft_conv(analyseBuffer, startChirpFourrier, resConvolution);
        for (int i = 0; i < sizeFft; i++) {
            resConvolution[i] *= ponderation[i];
            if (i < sizeFft - diff) {
                resConvolution[i] += recouvBuffer[i];
            }
            if (i >= diff) {
                recouvBuffer[i - diff] = resConvolution[i];
            }
        }

        TsUtils.Teager(resConvolution, teagerConvolution, sizeFft);
        MaxValIndexFloat upMax = TsUtils.findMaxIndexFloat(teagerConvolution, diff, 0);
        float kurtosis = 0;
        if (upMax.max > 0) {
            float[] values = Arrays.copyOf(teagerConvolution, diff);
            // /////////////////////////////////////////////
            // We compute the kurtosis an get the max
            kurtosis = kurtosis(values, upMax.max);
        }


        //Log.d("values", ""+ kurtosis + " ; " + upMax.max );
        if (upMax.max > threshMax && kurtosis > threshKurt) {
            //Log.d("Detection", "Detected");
            notifyListenerStartDetected(// we skip the start signal
                    Arrays.copyOfRange(analyseSounds, upMax.index, nbBuffers * blockSize + upMax.index));
            String blop = String.format("%04d", compt);
            //Log.d("Analysis",blop);

        }

    }

    private StartDetectedListener mListener = null;

    public void setListener(StartDetectedListener l) {
        mListener = l;
    }

    private void notifyListenerStartDetected(float[] recorded) {
        if (mListener != null) {
            mListener.onSignalReceived(recorded);
        }
    }

    public void startDetection() {
        if (recordTask.isCancelled()) {
            recordTask = new RecordAudio();
        }
        recordTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    public void stopDetection() {
        if (!recordTask.isCancelled()) {
            recordTask.cancel(true);
        }
    }

    void createChirp() {
        computeChirp(startChirpTemporal, f2, f1, lChirp, 0);
        float[] env_amplitude = new float[lChirp];
        TsUtils.tukeywin(env_amplitude, lChirp, .25f);
        int i;
        for (i = 0; i < lChirp; i++) {
            startChirpTemporal[i] *= env_amplitude[i];
        }
        // Pad
        startChirpFourrier = Arrays.copyOf(startChirpTemporal, sizeFft);
        fft.realForward(startChirpFourrier);

    }


    void computeChirp(float[] chirp, double freq_1, double freq_2, int size,
                      float phase) {
        float amplitude = 0.8f;
        float low_freq_radians = (float) (freq_1 * 2 * TsUtils.M_PI / sampleRate);
        float hi_freq_radians = (float) (freq_2 * 2 * TsUtils.M_PI / sampleRate);
        for (int i = 0; i < size; i++) {
            phase += ((hi_freq_radians - low_freq_radians) / size) * i
                    + low_freq_radians;
            chirp[i] = (float) (amplitude * Math.sin(phase));
        }
    }

    private static float kurtosis(float[] values, float max) {
        // Mean of values
        float sum = 0.0f;
        for (float f : values) {
            sum += f / max;
        }

        float mean = sum / (float) values.length;
        float num = 0.0f;
        float denom = 0.0f;

        for (float f : values) {
            num += Math.pow(f / max - mean, 4);
            denom += Math.pow(f / max - mean, 2);
        }

        num *= values.length;
        denom = (float) Math.pow(denom, 2);

        if (denom == 0.f) {
            return 0;
        } else {
            return num / denom;
        }
    }
}