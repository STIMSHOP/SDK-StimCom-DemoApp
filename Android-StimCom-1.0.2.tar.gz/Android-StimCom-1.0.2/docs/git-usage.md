How to use GIT branches
=======================

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->


- [master](#master)
- [develop](#develop)
- [feature/x](#featurex)
- [release/x.y.z](#releasexyz)
- [hotfix/x.y.z](#hotfixxyz)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## master

This is the latest stable release

## develop

This is the latest development version. One should not commit directly here, you should create
feature branches instead.

## feature/x

This is a temporary branch for the development of a feature. See [gitflow](https://fr.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow/)
for more information.

This kind of branch is forked from `develop`.

Once ready, a feature branch gets merged into `develop` and deleted.

## release/x.y.z

This is a temporary branch for a release. See [gitflow](https://fr.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow/)
for more information.

This kind of branch is forked from `develop`.

Once ready, a release branch gets merged into `master` and `develop` and deleted. There is also a tag
created on `master` at this point in order to identify that release name.

## hotfix/x.y.z

This is a temporary branch for a fix on a previous release. See [gitflow](https://fr.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow/)
for more information.

This kind of branch is forked from `master`, usually at the point in time where the issue was
identified (e.g. `hotfix/3.0.1` could be started from `master` at tag `3.0.0`).

Once ready, a hotfix branch gets merged into `master` and `develop` and deleted. A tag can optionally
be created too.

