Getting started
===============

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->


- [Include the SDK in your project](#include-the-sdk-in-your-project)
- [Get an API key](#get-an-api-key)
- [Update the application manifest](#update-the-application-manifest)
  - [Add permissions](#add-permissions)
  - [Declare the services for detection](#declare-the-services-for-detection)
  - [Add your custom permission](#add-your-custom-permission)
- [Initialize the StimCom SDK](#initialize-the-stimcom-sdk)
- [Configure the SDK](#configure-the-sdk)
  - [Using an XML resource file](#using-an-xml-resource-file)
  - [Using Java code](#using-java-code)
- [Implement the BroadcastReceiver](#implement-the-broadcastreceiver)
  - [Global receiver](#global-receiver)
  - [Activity-related receiver](#activity-related-receiver)
  - [Listening Policy](#listening-policy)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Include the SDK in your project

Find the latest version of the library in the ZIP file. It should be named `stimcom-sdk-commons-<X.Y.Z>.aar`,
where `<X.Y.Z>` is the release version.

- Copy the AAR file into your application module's `libs` directory
- Add the following line to your application module's `build.gradle` file, in the dependencies section:

```
    // SDK dependencies
    compile 'com.android.support:support-v4:23.1.1'
    compile 'com.android.support:support-annotations:23.1.1'
    compile 'com.google.guava:guava:18.0'
    compile 'net.sourceforge.jtransforms:jtransforms:2.4.0'

    // SDK library
    compile(name:'stimcom-sdk-commons-<X.Y.Z>', ext:'aar') {
        transitive=true
    }
```

Now you can synchronize the project with the gradle files (either from the toolbar button or from the
menu `Tools > Android > Sync project with Gradle files`.

> **TODO** Using a Maven repository would allow the user to only specify the SDK dependency. All other
dependencies would be pull automatically.

## Update the application manifest

### Add permissions

```xml
    <!-- ALLOW RECORDING AUDIO TO DETECT SIGNALS -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
```

### Add your custom permission

This step is only required if you plan to use the system broadcaster. If your application does not
need to communicate with other applications, you can ignore it. The SDK will by default use a local
broadcaster which does not transmit the messages outside of the application.

In order to prevent other apps from receiving your messages. You will have to create your own
permission and declare you will use it:

```xml
    <permission
        android:name="<YOUR.PACKAGE.NAME>.permission.STIMCOM_MESSAGE"
        android:protectionLevel="signature" />

    <uses-permission android:name="<YOUR.PACKAGE.NAME>.permission.STIMCOM_MESSAGE" />
```

**Note**: it is important to follow the scheme `<YOUR.PACKAGE.NAME>.permission.STIMCOM_MESSAGE`

## Initialize the StimCom SDK

The StimCom SDK must be initialized in a custom application class.

```java
package <YOUR.PACKAGE.NAME>;
import com.stimcom.sdk.common.StimCom;

public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();
        StimCom.create(this)
            .enableDebug(BuildConfig.DEBUG) // This is optional
            .start();
    }
}
```

Don't forget to tell Android to use that custom class in your `AndroidManifest.xml` file:

```xml
    <application
        android:name="<YOUR.PACKAGE.NAME>.Application"
        ...
```

## Configure the SDK

### Using an XML resource file

The SDK can be configured using an XML file. You can create the file `src/main/res/values/stimcom.xml`
in your application module's with the following content:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- DETECTORS TO ENABLE -->
    <string-array name="stimcom_detectors">
        <item>audio</item>
    </string-array>

    <!-- EMITTERS TO ENABLE -->
    <string-array name="stimcom_emitters">
        <item>audio</item>
    </string-array>

    <!-- MESSENGER TYPE (optional, defaults to local_broadcaster) -->
    <string name="stimcom_messenger">local_broadcaster</string>

    <!-- Enable debugging info/developer mode (optional, defaults to false) -->
    <bool name="stimcom_debug_enabled">true</bool>
</resources>
```

This file will automatically be used when you initialize the SDK in the application with the code snippet in the
previous section.

### Using Java code

However, if you prefer, you can also configure the SDK directly from code. In which case you don't need to create
that XML file and you need to change the initialization code as below:

```java
public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();
        StimCom.create(this)
            .withConfiguration(
                    new JavaConfiguration.Builder()
                            .requestedDetectorTypes(new Detector.Type[]{
                                    Detector.Type.AUDIO})
                            .requestedEmitterTypes(new Emitter.Type[]{
                                    Emitter.Type.AUDIO})
                            .build())
            .start();
    }
}
```

## Implement the BroadcastReceiver

The StimCom SDK communicates with you via broadcast messages which is built in the Android SDK.

You have two options. You can either have a receiver which receives detection signals even when the
application is not in foreground, or you can have a receiver which is tied to an activity.

### Global receiver

First, register the receiver in your `AndroidManifest.xml` file:

```xml
    <receiver android:name="<YOUR.PACKAGE.NAME>.MyReceiver">
        <intent-filter>
            <action android:name="com.stimcom.sdk.action.RECEIVE_MESSAGES" />
            <category android:name="android.intent.category.DEFAULT" />
        </intent-filter>
    </receiver>
```

**Note**: above, we assume the receiver will be implemented in the `MyReceiver` class
located in the package `<YOUR.PACKAGE.NAME>` (replace with your own names).

Then create a class which overrides the methods your care about from the SDK's
`StimComBroadcastReceiver` class:

```java
public class MyReceiver extends StimComBroadcastReceiver {
    @Override
    protected void onSignalDetected(Context context, Detector.Type detectorType, String signalCode, Proximity proximity) {
        // Do something with that code
    }
}
```

Please note that depending on the configuration in the `stimcom.xml`, not all functions will be
called. By default only the callback `onSignalCodeIdentified` would be called.

### Activity-related receiver

You don't need to declare the receiver in the manifest. Instead, you will register it directly from
the activity. Here is a sample activity code:

```java
public class MyActivity extends Activity {

    @Override
    protected void onResume() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(StimComBroadcastReceiver.BROADCAST_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver, filter);
        super.onResume();
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);
        super.onPause();
    }

    private StimComBroadcastReceiver myReceiver = new StimComBroadcastReceiver() {
        @Override
        protected void onSignalDetected(Context context, Detector.Type detectorType, String signalCode, Proximity proximity) {
            // Do something with that code
            Toast.makeText(context, code, Toast.LENGTH_SHORT).show();
        }
    };
}
```

### Listening Policy

You can start and stop listening whenever you want (provided the SDK is ready) by calling the `StimCom` methods
`startDetection()` and `stopDetection()`.

Detection is always a burden on the device's battery, so you should try as much as possible to detect only when
necessary. If you need to keep detection enabled for a long period of time, the SDK will soon provide a way to
enable/disable a power saving mode which would give better battery life in exchange for a higher detection latency.

### Emission Policy

You can start and stop emitting whenever you want (provided the SDK is ready) by calling the `StimCom` methods
`startEmission()` and `stopEmission()`.

Emission is always a burden on the device's battery, so you should try as much as possible to detect only when
necessary. If you need to keep emission enabled for a long period of time, the SDK will soon provide a way to
enable/disable a power saving mode which would give better battery life in exchange for a higher detection latency.