How to build the SDK
====================

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->


- [Requirements](#requirements)
- [Signing configuration](#signing-configuration)
  - [Providing the path to those files](#providing-the-path-to-those-files)
  - [Signing configuration](#signing-configuration-1)
  - [Project structure](#project-structure)
    - [library-commons](#library-commons)
    - [demo-audio](#demo-audio)
  - [Build for release](#build-for-release)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Requirements

- Android Studio (latest stable release)
- Android SDK

## Signing configuration

Before building you must provide a valid signing gradle file as well as the path to the keystore which
will be used to sign the demo applications and the libraries

### Providing the path to those files

Open the system `gradle.properties` file:

- On Windows: this is usually located in your user directory: `c:\users\<USER>\.gradle`
- On Mac/Linux: *to be detailled*

You can then add a line with the path to your files. Those files can be located anywhere on your
system. Usually this is a good idea to centralize your signing configurations in your user directory.
For example, this line could be:

```
SIGNING_STIMCOM_SDK=D:/users/<USER>/.signing/stimcom-sdk
```

The gradle file will then have to be named `stimcom-sdk.gradle` and the keystore file will be named
`stimcom-sdk.jks`.

### Signing configuration

Here is a sample `stimcom-sdk.gradle` file:

```
android {
  signingConfigs {
    release {
      storeFile file(getProperty(SIGNING_PROPERTY_NAME) + ".jks")
      storePassword "<MY_STORE_PASSWORD>"
      keyAlias "<MY_ALIAS>"
      keyPassword "<MY_KEY_PASSWORD>"
    }
  }

  buildTypes {
    release {
      signingConfig signingConfigs.release
    }
  }
}
```

You then have to replace the store password, key alias and key password with the proper ones.

Once everything is configured, you should then be able to build the demo applications and the libraries
in both release and debug configurations.

### Project structure

#### library-commons

This is the base library for the SDK.

#### demo

This is a sample application to demonstrate audio detection and emission

### Build for release

1. Prepare a release branch with gitflow, make all the adjustments and finish the release. This
will merge that release branch into `master` and `develop`, and it will create a tag named after the
version number.
1. In Android Studio, open the terminal and execute the command `gradlew aR` to build all binaries
1. In Android Studio, open the terminal and execute the command `gradlew makeDist` to prepare the
 release archive.

You will get a new zip file in the `dist` folder which contains the SDK ready for release.