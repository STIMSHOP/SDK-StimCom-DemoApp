package com.stimcom.sdk.demo;

import com.crashlytics.android.Crashlytics;
import com.stimcom.sdk.common.StimCom;

import io.fabric.sdk.android.Fabric;

/**
 * Custom application class
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public class Application extends android.app.Application {

    @Override
    public void onCreate() {
        super.onCreate();

        if (!BuildConfig.DEBUG) {
            Fabric.with(this, new Crashlytics());
        }
//
        StimCom.create(this)
//                .enableDebug(true)
//// You can also specify the configuration from the code directly if you prefer
////                .withConfiguration(
////                        new JavaConfiguration.Builder()
////                                .requestedDetectors(new Detector.Type[]{
////                                        Detector.Type.AUDIO})
////                                .build())
                .start();
    }
}
