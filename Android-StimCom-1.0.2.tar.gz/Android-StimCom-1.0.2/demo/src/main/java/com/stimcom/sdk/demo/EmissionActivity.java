package com.stimcom.sdk.demo;

import android.content.Context;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SwitchCompat;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.common.base.Strings;
import com.stimcom.sdk.audio.Constants;
import com.stimcom.sdk.common.StimCom;
import com.stimcom.sdk.common.messages.Messages;
import com.stimcom.sdk.common.messages.broadcaster.AbstractBroadcaster;
import com.stimcom.sdk.common.messages.broadcaster.StimComBroadcastReceiver;
import com.stimcom.sdk.common.model.Signal;
import com.stimcom.sdk.common.utils.Timber;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnTextChanged;

/**
 * Activity which demonstrates how to emit a signal using the SDK
 * <p/>
 * Created by Romain on 30/09/2015.
 */
public class EmissionActivity extends AppCompatActivity {

    // The StimCom object
    StimCom stimCom;

    // region Our views

    @Bind(R.id.sw_initialize)
    SwitchCompat initializeSwitch;

    @Bind(R.id.sw_toggle_detection)
    SwitchCompat toggleEmissionSwitch;

    @Bind(R.id.tv_signal_code)
    EditText tvSignalCode;

    // endregion

    // region Activity lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_emission);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        ButterKnife.bind(this);

        initializeSwitch.setEnabled(false);
        toggleEmissionSwitch.setEnabled(false);
        toggleEmissionSwitch.setChecked(false);

        stimCom = StimCom.get();
    }

    @Override
    protected void onResume() {
        // Register the local broadcast receiver at activity level
        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,
                new IntentFilter(AbstractBroadcaster.ACTION_RECEIVE_MESSAGES));

        updateSwitches();

        super.onResume();
    }

    @Override
    protected void onPause() {
        // Don't forget to unregister the receiver. Else you'll leak the context, and hence, memory!
        LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);

        super.onPause();
    }

    @Override
    protected void onDestroy() {
        ButterKnife.unbind(this);
        super.onDestroy();
    }

    // endregion

    @OnTextChanged(R.id.tv_signal_code)
    public void onSignalCodeTextChanged(CharSequence text) {
        if (text.length() == Constants.NB_CHAR) {
            toggleEmissionSwitch.setEnabled(true);
        } else {
            toggleEmissionSwitch.setEnabled(false);
            toggleEmissionSwitch.setChecked(false);
        }
    }

    // Handles the listen switch
    @OnCheckedChanged(R.id.sw_toggle_detection)
    public void onToggleAudioEmission(CompoundButton view, boolean isChecked) {
        if (isChecked && !stimCom.isEmitting()) {
            Timber.d("Starting emission");
            Signal signal = new Signal();
            signal.code = tvSignalCode.getText().toString();

            stimCom.startEmission(signal);
        } else if (!isChecked && stimCom.isEmitting()) {
            Timber.d("Stopping emission");
            stimCom.stopEmission();
        }
    }

    public void updateSwitches() {
        updateSwitches(false);
    }

    public void updateSwitches(boolean isError) {
        if (isError) {
            initializeSwitch.setChecked(false);
            toggleEmissionSwitch.setChecked(false);
            toggleEmissionSwitch.setEnabled(false);
            return;
        }

        initializeSwitch.setChecked(stimCom.isReady());

        toggleEmissionSwitch.setEnabled(stimCom.isReady());
        toggleEmissionSwitch.setChecked(stimCom.isEmitting());
    }

    // Listens to the detection messages
    private StimComBroadcastReceiver myReceiver = new StimComBroadcastReceiver() {

        @Override
        protected void onGenericError(Context context, int code, @Nullable String details) {
            switch (code) {
                // Init messages, they require
                case Messages.Error.NO_DETECTORS_AVAILABLE:
                case Messages.Error.REQUIRE_INTERNET_CONNECTIVITY:
                    updateSwitches(true);
                    break;

                case Messages.Error.AUDIO_EMISSION_ERROR:
                    stimCom.stopEmission();
                    toggleEmissionSwitch.setChecked(false);
                    break;
            }

            if (!Strings.isNullOrEmpty(details)) {
                Toast.makeText(EmissionActivity.this, details, Toast.LENGTH_LONG).show();
            }
        }

        @Override
        protected void onGenericInfo(Context context, int code, @Nullable String details) {
            if (!Strings.isNullOrEmpty(details)) {
                Toast.makeText(EmissionActivity.this, details, Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onEmissionStarted(Context context) {
            Toast.makeText(EmissionActivity.this, "Emission started", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onEmissionStopped(Context context) {
            Toast.makeText(EmissionActivity.this, "Emission stopped", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onStimComReady(Context context) {
            Toast.makeText(EmissionActivity.this, "StimCom is ready", Toast.LENGTH_SHORT).show();
            updateSwitches();
        }
    };


}
