package com.stimcom.sdk.demo;

import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SwitchCompat;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.common.base.Objects;
import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.stimcom.sdk.common.StimCom;
import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.detection.Proximity;
import com.stimcom.sdk.common.messages.Messages;
import com.stimcom.sdk.common.messages.broadcaster.AbstractBroadcaster;
import com.stimcom.sdk.common.messages.broadcaster.StimComBroadcastReceiver;
import com.stimcom.sdk.common.utils.Timber;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;


/**
 * Activity to receive signals
 * <p/>
 * Created by vprat on 03/12/2015.
 */
public class ReceptionActivity extends AppCompatActivity {

    // The StimCom object
    StimCom stimCom;

    // The signal that has been detected last
    Optional<String> latestSignal = Optional.absent();
    Proximity latestProximity = Proximity.UNKNOWN;

    // Statistics about reception
    Optional<ReceptionStatistics> statistics = Optional.absent();

    // region Our views

    @Bind(R.id.sw_initialize)
    SwitchCompat initializeSwitch;

    @Bind(R.id.sw_toggle_detection)
    SwitchCompat toggleDetectionSwitch;

    @Bind(R.id.tv_expected_signal)
    EditText tvExpectedSignal;

    @Bind(R.id.tv_period)
    EditText tvPeriod;

    // endregion

    // region Activity lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_reception);
        ButterKnife.bind(this);

        initializeSwitch.setEnabled(false);
        toggleDetectionSwitch.setEnabled(false);
        toggleDetectionSwitch.setChecked(false);

        stimCom = StimCom.get();
    }

    @Override
    protected void onResume() {
        // Register the local broadcast receiver at activity level
        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,
                new IntentFilter(AbstractBroadcaster.ACTION_RECEIVE_MESSAGES));

        updateSwitches();

        super.onResume();
    }

    @Override
    protected void onPause() {
        // Don't forget to unregister the receiver. Else you'll leak the context, and hence, memory!
        LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);

        super.onPause();
    }

    @Override
    protected void onDestroy() {
        ButterKnife.unbind(this);
        super.onDestroy();
    }

    // endregion

    // Handles the listen switch
    @OnCheckedChanged(R.id.sw_toggle_detection)
    public void onToggleAudioDetection(CompoundButton view, boolean isChecked) {
        if (isChecked && !stimCom.isDetecting()) {
            Timber.d("Starting detection");
            latestSignal = Optional.absent();
            stimCom.startDetection();
        } else if (!isChecked && stimCom.isDetecting()) {
            Timber.d("Stopping detection");
            stimCom.stopDetection();
        }
    }

    public void updateSwitches() {
        updateSwitches(false);
    }

    public void updateSwitches(boolean isError) {
        if (isError) {
            initializeSwitch.setChecked(false);
            toggleDetectionSwitch.setChecked(false);
            toggleDetectionSwitch.setEnabled(false);
            return;
        }

        initializeSwitch.setChecked(stimCom.isReady());

        toggleDetectionSwitch.setEnabled(stimCom.isReady());
        toggleDetectionSwitch.setChecked(stimCom.isDetecting());

    }

    // Listens to the detection messages
    private StimComBroadcastReceiver myReceiver = new StimComBroadcastReceiver() {

        @Override
        protected void onGenericError(Context context, int code, @Nullable String details) {
            switch (code) {
                // Init messages, they require
                case Messages.Error.NO_DETECTORS_AVAILABLE:
                case Messages.Error.REQUIRE_INTERNET_CONNECTIVITY:
                    updateSwitches(true);
                    break;
            }

            if (!Strings.isNullOrEmpty(details)) {
                Toast.makeText(ReceptionActivity.this, details, Toast.LENGTH_LONG).show();
            }
        }

        @Override
        protected void onGenericInfo(Context context, int code, @Nullable String details) {
            if (!Strings.isNullOrEmpty(details)) {
                Toast.makeText(ReceptionActivity.this, details, Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onDetectionStarted(Context context) {
            Toast.makeText(ReceptionActivity.this, "Detection started", Toast.LENGTH_SHORT).show();

            statistics = Optional.of(new ReceptionStatistics(
                    tvExpectedSignal.getText().toString(),
                    Double.parseDouble(tvPeriod.getText().toString())
            ));
        }

        @Override
        protected void onDetectionStopped(Context context) {
            Toast.makeText(ReceptionActivity.this, "Detection stopped", Toast.LENGTH_SHORT).show();

            Timber.d("Detection statistics:\n" + statistics.get().toString());
            statistics = Optional.absent();
        }

        @Override
        protected void onStimComReady(Context context) {
            Toast.makeText(ReceptionActivity.this, "StimCom is ready", Toast.LENGTH_SHORT).show();
            updateSwitches();
        }

        @Override
        protected void onSignalDetected(Context context, Detector.Type detectorType, String signalCode, Proximity proximity) {
            if (!Objects.equal(signalCode, latestSignal.orNull()) || proximity != latestProximity) {
                Toast.makeText(ReceptionActivity.this,
                        "Signal " + signalCode + " detected with proximity " + proximity.name(),
                        Toast.LENGTH_SHORT).show();

                latestSignal = Optional.of(signalCode);
                latestProximity = proximity;
            }

            if (statistics.isPresent()) statistics.get().newSignal(signalCode);
        }

        @Override
        protected void onDebugInformation(Context context, String code, @Nullable Bundle data) {
            if (statistics.isPresent()) {
                Timber.d("Debug message received: " + code);

                if ("Audio.onSignalAnalyzed".equals(code)) {
                    statistics.get().newAnalysis();
                } else if ("Audio.onSignalReceived".equals(code)) {
                    statistics.get().newDetection();
                }
            }
        }
    };
}

