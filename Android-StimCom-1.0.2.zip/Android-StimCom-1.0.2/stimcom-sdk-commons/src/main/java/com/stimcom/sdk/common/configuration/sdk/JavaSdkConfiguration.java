package com.stimcom.sdk.common.configuration.sdk;

import com.google.common.collect.Sets;
import com.stimcom.sdk.common.configuration.InvalidConfigurationException;
import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.messages.Messenger;

import java.util.Set;

/**
 * Implementation to build the configuration from code
 * <p/>
 * Here is some sample code:
 * <p/>
 * <pre><code>
 *  Configuration conf = new JavaConfiguration.Builder()
 *      .requestedDetectors(new Detector.Type[]{
 *          Detector.Type.AUDIO,
 *          Detector.Type.BLUETOOTH_LE})
 *      .build();
 * </code></pre>
 * Created by vprat on 01/07/2015.
 */
public class JavaSdkConfiguration implements SdkConfiguration {

    /**
     * A class to build the configuration
     */
    public static class Builder {
        JavaSdkConfiguration configuration;

        /**
         * Start by building the builder
         */
        public Builder() {
            this.configuration = new JavaSdkConfiguration();
        }

        public Builder requestedDetectors(Detector.Type[] detectorTypes) {
            if (detectorTypes == null || detectorTypes.length == 0) {
                throw new InvalidConfigurationException("1 or more detector types are required");
            }

            configuration.requestedDetectorTypes = Sets.newHashSet(detectorTypes);
            return this;
        }

        public Builder requestedEmitters(Emitter.Type[] emitterTypes) {
            if (emitterTypes == null || emitterTypes.length == 0) {
                throw new InvalidConfigurationException("1 or more emitter types are required");
            }

            configuration.requestedEmitterTypes = Sets.newHashSet(emitterTypes);
            return this;
        }

        public Builder messengerType(Messenger.Type type) {
            configuration.messengerType = type;
            return this;
        }

        public SdkConfiguration build() throws InvalidConfigurationException {
            if (configuration.requestedDetectorTypes == null)
                throw new InvalidConfigurationException("You must indicate the detector types you are requesting");

            if (configuration.requestedEmitterTypes == null)
                throw new InvalidConfigurationException("You must indicate the emitter types you are requesting");

            if (configuration.messengerType == null)
                throw new InvalidConfigurationException("You must indicate the messenger type you want to use");

            return configuration;
        }
    }

    private Messenger.Type messengerType = Messenger.Type.LOCAL_BROADCASTER;
    private Set<Detector.Type> requestedDetectorTypes = null;
    private Set<Emitter.Type> requestedEmitterTypes = null;

    @Override
    public Set<Detector.Type> getRequestedDetectorTypes() {
        return requestedDetectorTypes;
    }

    @Override
    public Set<Emitter.Type> getRequestedEmitterTypes() {
        return requestedEmitterTypes;
    }

    @Override
    public Messenger.Type getMessengerType() {
        return messengerType;
    }

    /**
     * Make use of {@link JavaSdkConfiguration.Builder} to build an object of this kind
     */
    protected JavaSdkConfiguration() {
    }
}
