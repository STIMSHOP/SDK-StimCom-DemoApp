package com.stimcom.sdk.audio.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Romain on 30/09/2015.
 */
public class Decoder {

    private static final int BASE_CRC = 64;
    private static final List<Indices> INDEX_LIST;
    private static final String CHAR_LIST = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private int nbChar, nbCrc;

    public Decoder(int nbChar, int nbCrc) {
        super();
        this.nbChar = nbChar;
        this.nbCrc = nbCrc;
    }

    public String decode(List<Indices> indices) {
        int[] inds = new int[nbChar + nbCrc];

        // TODO Use StringBuffer instead (pre-allocate one)
        String res = new String();
        //int n = indices.size();
        for (int i = 0; i < (nbChar + nbCrc); i++) {
            Indices analyse = indices.get(i);
            inds[i] = INDEX_LIST.indexOf(analyse);
        }
        //
        //Log.d("inds", ""+inds[0]+inds[1]+inds[2]+inds[3]+inds[4]+inds[5]+inds[6]+inds[7]);
        boolean crc_ok = rs_check(inds);
        //Log.d("bool", ""+crc_ok);
        if (crc_ok) {
            for (int i = 0; i < (nbChar); i++) {
                if (inds[i] < CHAR_LIST.length()) {
                    res += CHAR_LIST.charAt(inds[i]);
                }
            }
            if (res.length() == nbChar) {
                return res;
                //Log.d("Detection","Decoded");
            }
        }

        return null;
    }

    public List<Indices> encode(String code) {
        int nb_c = code.length();
        List<Indices> res = new ArrayList<Indices>();
        for (int i = 0; i < nb_c; i++) {
            int pos = CHAR_LIST.indexOf(code.charAt(i));
            res.add(INDEX_LIST.get(pos));
        }
        res.add(INDEX_LIST.get(rs_sum(code)));
        res.add(INDEX_LIST.get(rs_prod(code)));
        return res;
    }

    private boolean rs_check(int[] inds) {
        int sum_calc = rs_sum(inds);
        int prod_calc = rs_prod(inds);
        //Log.d("calc", ""+sum_calc+","+prod_calc);
        if (sum_calc == inds[nbChar] || prod_calc == inds[nbChar + 1]) {
            return true;
        } else {
            int val_err = (sum_calc - inds[nbChar]);
            if (val_err < 0) {
                val_err += BASE_CRC;
            }
            int j = 0;
            int pos_err = 0;
            int diff_prod = prod_calc - inds[nbChar + 1];
            while (j < 6) {
                if ((diff_prod % (val_err)) == 0) {
                    pos_err = Math.abs(diff_prod) / Math.abs(val_err);
                    break;
                } else {
                    j++;
                    diff_prod += BASE_CRC;
                }
            }
            if (pos_err > 0 && pos_err <= nbChar) {
                inds[pos_err - 1] -= val_err;
                if (inds[pos_err - 1] < 0) {
                    inds[pos_err - 1] += BASE_CRC;
                }
                if (inds[pos_err - 1] >= BASE_CRC) {
                    inds[pos_err - 1] -= BASE_CRC;
                }
                //Log.d("Detection", "Correction réussie " + Arrays.toString(inds));
                return true;
            }
            return false;
        }
    }

    /**
     * Calculate the sum digit for RS code
     */
    int rs_sum(String source) {
        int i;
        int count, sum_digit;
        count = 0;

        for (i = 0; i < nbChar; i++) {
            count += CHAR_LIST.indexOf((source.charAt(i)));
        }
        sum_digit = (count % BASE_CRC);
        if (sum_digit == BASE_CRC) {
            sum_digit = 0;
        }
        //Log.d("encoder", ""+sum_digit);
        return sum_digit;
    }

    /**
     * Calculate the sum digit for RS code
     */
    int rs_sum(int[] source) {
        int i;
        int count, sum_digit;
        count = 0;

        for (i = 0; i < nbChar; i++) {
            count += (source[i]);
        }
        sum_digit = (count % BASE_CRC);
        if (sum_digit == BASE_CRC) {
            sum_digit = 0;
        }
        //Log.d("encoder", ""+sum_digit);
        return sum_digit;
    }

    /**
     * Calculate the sum product digit for RS code
     */
    int rs_prod(String source) {
        int i;
        int count, prod_digit;
        count = 0;

        for (i = 0; i < nbChar; i++) {
            count += (i + 1) * CHAR_LIST.indexOf((source.charAt(i)));
        }
        prod_digit = (count % BASE_CRC);
        if (prod_digit == BASE_CRC) {
            prod_digit = 0;
        }
        //Log.d("encoder", ""+prod_digit);
        return prod_digit;
    }

    /**
     * Calculate the sum product digit for RS code
     */
    int rs_prod(int[] source) {
        int i;
        int count, prod_digit;
        count = 0;

        for (i = 0; i < nbChar; i++) {
            count += (i + 1) * (source[i]);
        }
        prod_digit = (count % BASE_CRC);
        if (prod_digit == BASE_CRC) {
            prod_digit = 0;
        }
        //Log.d("encoder", ""+prod_digit);
        return prod_digit;
    }

    static {
        INDEX_LIST = new ArrayList<>();
        INDEX_LIST.add(new Indices(10, 11));//0
        INDEX_LIST.add(new Indices(0, 1));//1
        INDEX_LIST.add(new Indices(9, 11));//2
        INDEX_LIST.add(new Indices(0, 2));//3
        INDEX_LIST.add(new Indices(9, 10));//4
        INDEX_LIST.add(new Indices(1, 2));//5
        INDEX_LIST.add(new Indices(8, 11));//6
        INDEX_LIST.add(new Indices(0, 3));//7
        INDEX_LIST.add(new Indices(8, 10));//8
        INDEX_LIST.add(new Indices(1, 3));//9
        INDEX_LIST.add(new Indices(7, 11));//A
        INDEX_LIST.add(new Indices(0, 4));//B
        INDEX_LIST.add(new Indices(8, 9));//C
        INDEX_LIST.add(new Indices(2, 3));//D
        INDEX_LIST.add(new Indices(7, 10));//E
        INDEX_LIST.add(new Indices(1, 4));//F
        INDEX_LIST.add(new Indices(6, 11));//G
        INDEX_LIST.add(new Indices(0, 5));//H
        INDEX_LIST.add(new Indices(0, 11));//I
        INDEX_LIST.add(new Indices(7, 9));//J
        INDEX_LIST.add(new Indices(2, 4));//K
        INDEX_LIST.add(new Indices(7, 8));//L
        INDEX_LIST.add(new Indices(3, 4));//M
        INDEX_LIST.add(new Indices(5, 11));//N
        INDEX_LIST.add(new Indices(0, 6));//O
        INDEX_LIST.add(new Indices(6, 10));//P
        INDEX_LIST.add(new Indices(1, 5));//Q
        INDEX_LIST.add(new Indices(1, 11));//R
        INDEX_LIST.add(new Indices(0, 10));//S
        INDEX_LIST.add(new Indices(6, 7));//T
        INDEX_LIST.add(new Indices(4, 5));//U
        INDEX_LIST.add(new Indices(4, 11));//V
        INDEX_LIST.add(new Indices(0, 7));//W
        INDEX_LIST.add(new Indices(6, 9));//X
        INDEX_LIST.add(new Indices(2, 5));//Y
        INDEX_LIST.add(new Indices(5, 6));//Z
        INDEX_LIST.add(new Indices(6, 8));
        INDEX_LIST.add(new Indices(3, 5));
        INDEX_LIST.add(new Indices(2, 11));
        INDEX_LIST.add(new Indices(0, 9));
        INDEX_LIST.add(new Indices(3, 11));
        INDEX_LIST.add(new Indices(0, 8));
        INDEX_LIST.add(new Indices(5, 10));
        INDEX_LIST.add(new Indices(1, 6));
        INDEX_LIST.add(new Indices(1, 10));
        INDEX_LIST.add(new Indices(5, 7));
        INDEX_LIST.add(new Indices(4, 6));
        INDEX_LIST.add(new Indices(5, 9));
        INDEX_LIST.add(new Indices(2, 6));
        INDEX_LIST.add(new Indices(5, 8));
        INDEX_LIST.add(new Indices(4, 10));
        INDEX_LIST.add(new Indices(3, 6));
        INDEX_LIST.add(new Indices(1, 7));
        INDEX_LIST.add(new Indices(2, 10));
        INDEX_LIST.add(new Indices(1, 9));
        INDEX_LIST.add(new Indices(3, 10));
        INDEX_LIST.add(new Indices(1, 8));
        INDEX_LIST.add(new Indices(4, 7));
        INDEX_LIST.add(new Indices(4, 9));
        INDEX_LIST.add(new Indices(2, 7));
        INDEX_LIST.add(new Indices(4, 8));
        INDEX_LIST.add(new Indices(3, 7));
        INDEX_LIST.add(new Indices(2, 9));
        INDEX_LIST.add(new Indices(3, 9));
        INDEX_LIST.add(new Indices(2, 8));
        INDEX_LIST.add(new Indices(3, 8));
    }

}
