package com.stimcom.sdk.common.messages.broadcaster;

import android.content.Context;
import android.content.Intent;

/**
 * Class which allows sending our messages using the Android broadcast system on a system-wide level.
 * If you do not plan to let other applications use your messages, you should use the LocalBroadcaster
 * class instead (for better security and performance)
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public class SystemBroadcaster extends AbstractBroadcaster {

    // Suffix on the app package name to make the permission name
    private static final String BROADCAST_PERMISSION_FILTER_SUFFIX = ".permission.STIMCOM_MESSAGE";

    // The permission to require on receivers to protect our messages from other apps
    private final String receiverPermission;

    /**
     * Constructor
     *
     * @param context The application context
     */
    public SystemBroadcaster(Context context) {
        super(context);
        this.receiverPermission = context.getPackageName() + BROADCAST_PERMISSION_FILTER_SUFFIX;
    }

    /**
     * Send a broadcast with the required permission
     *
     * @param broadcast The broadcast to send
     */
    @Override
    protected void sendPrivateBroadcast(Intent broadcast) {
        context.sendBroadcast(broadcast, receiverPermission);
    }
}
