package com.stimcom.sdk.audio.detection;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.utils.Timber;

import java.util.List;

/**
 * This audio detector implementation is based on a service which does all the work for us. The detector simply
 * starts and stops the service.
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public class AudioDetector implements Detector {

    private Context context;

    /**
     * Constructor
     *
     * @param context The application context
     */
    public AudioDetector(Context context) {
        this.context = context;
    }

    @Override
    public Type getType() {
        return Type.AUDIO;
    }

    @Override
    public boolean isSupported() {
        PackageManager pm = context.getPackageManager();

        // Microphone is provided
        if (!pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)) {
            Timber.w("This device does not seem to have a microphone");
            return false;
        }

        // RECORD_AUDIO permission is there
        int permissionCheck = pm.checkPermission(
                android.Manifest.permission.RECORD_AUDIO,
                context.getPackageName());
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            Timber.w("Audio detector needs the android.permission.RECORD_AUDIO permission");
            return false;
        }

        // Service is properly declared in the manifest
        final Intent intent = new Intent(context, AudioDetectionService.class);
        List resolveInfo = pm.queryIntentServices(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (resolveInfo.size() == 0) {
            Timber.w("The AudioDetectionService is not properly declared in the AndroidManifest.xml");
            return false;
        }

        return true;
    }

    @Override
    public boolean isReady() {
        // Always ready?
        // TODO Maybe check if we are already recording somewhere else? Like a phone call for example.
        return true;
    }

    @Override
    public boolean isDetecting() {
        return AudioDetectionService.isRunning();
    }

    @Override
    public void start() {
        context.startService(AudioDetectionService.newIntent(context));
    }

    @Override
    public void stop() {
        context.stopService(AudioDetectionService.newIntent(context));
    }
}
