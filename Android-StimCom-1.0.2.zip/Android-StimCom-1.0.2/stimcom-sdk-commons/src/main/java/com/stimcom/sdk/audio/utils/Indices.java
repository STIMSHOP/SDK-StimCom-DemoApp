package com.stimcom.sdk.audio.utils;

/**
 * Created by Romain on 08/10/2015.
 */
public class Indices {
    int ind1, ind2;

    public Indices(int ind1, int ind2) {
        if (ind1 < ind2) {
            this.ind1 = ind1;
            this.ind2 = ind2;
        } else {
            this.ind1 = ind2;
            this.ind2 = ind1;
        }


    }

    public int getInd1() {
        return ind1;
    }

    public int getInd2() {
        return ind2;
    }

    public void setInd1(int ind1) {
        this.ind1 = ind1;
    }

    public void setInd2(int ind2) {
        this.ind2 = ind2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Indices)) return false;

        Indices indices = (Indices) o;

        if (ind1 != indices.ind1) return false;
        return ind2 == indices.ind2;

    }

    @Override
    public int hashCode() {
        int result = ind1;
        result = 31 * result + ind2;
        return result;
    }
}
