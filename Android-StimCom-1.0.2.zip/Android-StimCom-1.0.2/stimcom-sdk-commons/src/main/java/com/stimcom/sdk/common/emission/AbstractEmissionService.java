package com.stimcom.sdk.common.emission;

import android.app.Service;


/**
 * Provides some useful logic common to each emission service
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public abstract class AbstractEmissionService extends Service {

}
