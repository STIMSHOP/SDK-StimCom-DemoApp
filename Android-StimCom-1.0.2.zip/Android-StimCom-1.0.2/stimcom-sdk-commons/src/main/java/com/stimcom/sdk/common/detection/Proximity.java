package com.stimcom.sdk.common.detection;

/**
 * An indication of the distance to a signal
 * <p/>
 * Created by vprat on 05/07/2015.
 */
public enum Proximity {

    // Very close, usually within 1 meter
    IMMEDIATE,

    // Somewhere withing 5 meters
    NEAR,

    // Further than 5 meters away
    FAR,

    // We can't tell how far the beacon is
    UNKNOWN;

    private static final int IMMEDIATE_RANGE_M = 1;
    private static final int NEAR_RANGE_M = 5;

    /**
     * Get the proximity from a string
     *
     * @param proximityId The string representation of the proximity (case-insensitive)
     * @return The proximity
     * @throws IllegalArgumentException If the proximity cannot be found
     */
    public static Proximity fromString(String proximityId) {
        for (Proximity t : Proximity.values()) {
            if (t.name().equalsIgnoreCase(proximityId)) {
                return t;
            }
        }
        throw new IllegalArgumentException(proximityId + " is not a valid Proximity");
    }

    /**
     * Get a proximity from a distance
     *
     * @param distance distance in meters
     * @return The proximity class
     */
    public static Proximity fromDistance(float distance) {
        if (distance <= 0) return Proximity.UNKNOWN;

        if (distance <= IMMEDIATE_RANGE_M) {
            return Proximity.IMMEDIATE;
        } else if (distance <= NEAR_RANGE_M) {
            return Proximity.NEAR;
        }

        return Proximity.FAR;
    }

}
