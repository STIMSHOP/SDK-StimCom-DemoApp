package com.stimcom.sdk.common.detection;

import android.app.Service;


/**
 * Provides some useful logic common to each detection service
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public abstract class AbstractDetectionService extends Service {

}
