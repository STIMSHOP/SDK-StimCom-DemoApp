package com.stimcom.sdk.audio.utils;

import android.content.Context;

import com.stimcom.sdk.common.utils.Timber;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

/**
 * Reads a pcm file
 * fakes the behavior of Audio Record
 *
 * @author vincent
 */
public class FakeAudioRecord {

    int periodInMillis;
    Date lastRead;

    int sampleRate;
    int blockSize;

    InputStream is;
    BufferedInputStream bis;
    DataInputStream dis;

    int ressourceID;
    Context context;

    /**
     * Construct fake audio record
     * <p/>
     * Resource file is intended to be a true pcm
     * unsigned 16 bit big endian
     * ffmpeg -i AB586.wav -f u16be -acodec pcm_u16be ab586.pcm
     *
     * @param context     necessary to open raw files
     * @param ressourceID the id of pcm file
     * @param sampleRate  sampleRate of pcm file
     * @param blockSize   size of chunks that will be read.
     */
    protected FakeAudioRecord(Context context, int ressourceID, int sampleRate,
                              int blockSize) {
        super();
        lastRead = new Date();
        this.context = context;
        this.ressourceID = ressourceID;
        this.sampleRate = sampleRate;
        this.blockSize = blockSize;
        periodInMillis = (1000 * blockSize) / sampleRate - 2;
        Timber.d(periodInMillis + " ms ");
        initData();
    }

    /**
     * Read raw ressources
     */
    private void initData() {
        Timber.d("initData");
        is = context.getResources().openRawResource(this.ressourceID);
        bis = new BufferedInputStream(is);
        dis = new DataInputStream(bis);

    }

    public int readFromFile(short[] buffer) {

        int res = 0;

        Date now;
        // waiting loop to keep synchronized song
        while (true) {
            now = new Date();
            if ((now.getTime() - lastRead.getTime()) > periodInMillis) {
                break;
            }
        }
        try {

            res = readBlockSize(buffer);

        } catch (IOException e) {
            // TODO Auto-generated catch block
            Timber.e(e.getMessage());

        }
        // We jeust read trace it.
        lastRead = new Date();
        return res;

    }

    private int readBlockSize(short[] buffer) throws IOException {
        int i = 0;
        for (i = 0; i < blockSize; i++) {
            if (dis.available() > 0) {
                buffer[i] = dis.readShort();
            } else {
                dis.close();
                initData();
            }
        }

        return i;
    }


}
