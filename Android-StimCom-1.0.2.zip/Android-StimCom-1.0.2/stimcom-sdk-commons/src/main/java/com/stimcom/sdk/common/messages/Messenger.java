package com.stimcom.sdk.common.messages;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.detection.Proximity;
import com.stimcom.sdk.common.model.Signal;

/**
 * Contract for the class responsible for sending our messages
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public interface Messenger {

    /**
     * The known types of detectors
     */
    enum Type {
        LOCAL_BROADCASTER,
        SYSTEM_BROADCASTER;

        /**
         * Get the type from a string
         *
         * @param typeId The string representation of the type (case-insensitive)
         * @return The type
         * @throws IllegalArgumentException If the type cannot be found
         */
        public static Type fromString(String typeId) {
            for (Type t : Type.values()) {
                if (t.name().equalsIgnoreCase(typeId)) {
                    return t;
                }
            }
            throw new IllegalArgumentException(typeId + " is not a valid Messenger.Type");
        }
    }

    /**
     * Tell the world we have detected a signal
     *
     * @param detectorType The type of detector which detected the signal
     * @param signal       The signal itself
     * @param proximity    How close the source of the signal seems to be
     */
    void sendOnSignalDetected(Detector.Type detectorType, Signal signal, Proximity proximity);

    /**
     * Tell the world the SDK is ready to be used
     */
    void sendOnStimComReady();

    /**
     * Tell the world we are emitting now
     */
    void sendOnEmissionStarted();

    /**
     * Tell the world we are not emitting anymore
     */
    void sendOnEmissionStopped();

    /**
     * Tell the world we are detecting now
     */
    void sendOnDetectionStarted();

    /**
     * Tell the world we are not detecting anymore
     */
    void sendOnDetectionStopped();

    /**
     * Tell the world that an error occurred
     *
     * @param errorCode    The error code
     * @param errorMessage The error message
     */
    void sendOnStimComError(int errorCode, @Nullable String errorMessage);

    /**
     * We have some debug information to send
     */
    void sendOnDebugInformation(String code, Bundle data);

    /**
     * We have some debug information to send
     */
    void sendOnDebugInformation(String code);
}