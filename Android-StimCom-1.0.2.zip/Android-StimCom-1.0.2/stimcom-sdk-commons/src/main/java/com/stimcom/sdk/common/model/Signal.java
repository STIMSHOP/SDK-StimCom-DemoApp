package com.stimcom.sdk.common.model;

public class Signal {

	public String code;

}
