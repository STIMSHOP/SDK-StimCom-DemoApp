package com.stimcom.sdk.audio;

/**
 * Constants used by audio emission and detection
 *
 * Created by vprat on 04/12/2015.
 */
public class Constants {

    // TODO allow configuration for that?
    public static final int SAMPLE_RATE = 48000;

    // TODO allow configuration for that?
    public static final int BASE_BUFFER_SIZE = 2048;

    // TODO allow configuration for that?
    public static final int NB_BUFFER_ANALYZED = 12;

    // TODO allow configuration for that?
    public static final int NB_FREQ = 12;

    // TODO allow configuration for that?
    public static final int NB_CHAR = 6;

    // TODO allow configuration for that?
    public static final int NB_CRC = 2;

    // TODO allow configuration for that?
    public static final double GAP = 187.5;

    // TODO allow configuration for that?
    public static final double F1 = 18000;

    // TODO allow configuration for that?
    public static final double F2 = F1 + (NB_FREQ - 1) * GAP;
}
