package com.stimcom.sdk.audio.utils;


/**
 * @author vincent
 *         <p/>
 *         This class is intended to hold base buffer data. It has some
 *         utilities built in. Seamless short array to double transform.
 */
public class StimBuffer {

    private int blockSize;
    float[] internalBuffer;
    private float sum;


    /**
     * Init internal array
     *
     * @param blockSize
     */
    public StimBuffer(int blockSize) {
        super();
        this.blockSize = blockSize;
        internalBuffer = new float[blockSize];
    }


    public float[] getBuffer() {
        return internalBuffer;
    }

    public float getSum() {
        return sum;
    }

    public float getSumFromIndex(int index) {
        float sum = 0f;
        for (int i = index; i < blockSize; i++) {
            sum += internalBuffer[i];
        }
        return sum;

    }


    /**
     * Set data Buffer
     *
     * @param shortBuffer short data buffer of retrieved from
     *                    AudioRecord.
     */
    public void setBuffer(short[] shortBuffer) {

        for (int i = 0; i < blockSize; i++) {
            internalBuffer[i] = (float) (shortBuffer[i] / 32768.0); // signed
        }


    }


}