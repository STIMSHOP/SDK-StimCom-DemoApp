package com.stimcom.sdk.common.messages;

import android.content.Context;
import android.support.annotation.NonNull;

import com.stimcom.sdk.common.messages.broadcaster.LocalBroadcaster;
import com.stimcom.sdk.common.messages.broadcaster.SystemBroadcaster;

/**
 * Default implementation for the factory
 * <p/>
 * Created by vprat on 03/12/2015.
 */
public class DefaultMessengerFactory implements MessengerFactory {

    private Context context;

    /**
     * Constructor
     *
     * @param context The application context
     */
    public DefaultMessengerFactory(Context context) {
        this.context = context;
    }

    @Override
    public Messenger newMessenger(@NonNull Messenger.Type type) throws IllegalArgumentException {
        switch (type) {
            case LOCAL_BROADCASTER:
                return new LocalBroadcaster(context);

            case SYSTEM_BROADCASTER:
                return new SystemBroadcaster(context);

            default:
                throw new RuntimeException(type.toString() + " does not match any of our known Messenger types");
        }
    }
}
