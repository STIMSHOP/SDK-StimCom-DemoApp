package com.stimcom.sdk.audio.emission;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.model.Signal;
import com.stimcom.sdk.common.utils.Timber;

import java.util.List;

/**
 * This audio emitter implementation is based on a service which does all the work for us. The emitter simply
 * starts and stops the service.
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public class AudioEmitter implements Emitter {

    private Context context;
    private Signal currentSignal;

    /**
     * Constructor
     *
     * @param context The application context
     */
    public AudioEmitter(Context context) {
        this.context = context;
    }

    @Override
    public Type getType() {
        return Type.AUDIO;
    }

    @Override
    public boolean isSupported() {
        PackageManager pm = context.getPackageManager();

        // Service is properly declared in the manifest
        final Intent intent = new Intent(context, AudioEmissionService.class);
        List resolveInfo = pm.queryIntentServices(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (resolveInfo.size() == 0) {
            Timber.w("The AudioEmissionService is not properly declared in the AndroidManifest.xml");
            return false;
        }

        return true;
    }

    @Override
    public boolean isReady() {
        // Always ready?
        // TODO Maybe check if we are already recording somewhere else? Like a phone call for example.
        return true;
    }

    @Override
    public boolean isEmitting() {
        return AudioEmissionService.isRunning();
    }

    @Override
    public void start(Signal signal) {
        this.currentSignal = signal;
        context.startService(AudioEmissionService.newIntent(context, currentSignal));
    }

    @Override
    public void stop() {
        context.stopService(AudioEmissionService.newIntent(context, currentSignal));
        this.currentSignal = null;
    }
}
