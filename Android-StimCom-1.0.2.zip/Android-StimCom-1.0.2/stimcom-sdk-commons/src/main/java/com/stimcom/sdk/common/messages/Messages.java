package com.stimcom.sdk.common.messages;

/**
 * Convenience class to centralize all message constants
 * <p/>
 * Created by vprat on 03/07/2015.
 */
public final class Messages {

    /**
     * Convenience class to centralize all message categories which are sent via broadcast
     */
    public static class Category {
        public static final int INFO = 0x0001;
        public static final int ERROR = 0x0002;
        public static final int DETECTION = 0x0003;
        public static final int DEBUG = 0x0004;
    }

    /**
     * Convenience class to centralize all info codes which are sent via broadcast
     */
    public static class Info {
        // General info
        public static final int STIMCOM_READY = 0x1001;
        public static final int DETECTION_STARTED = 0x1002;
        public static final int DETECTION_STOPPED = 0x1003;
        public static final int EMISSION_STARTED = 0x1004;
        public static final int EMISSION_STOPPED = 0x1005;
    }

    /**
     * Convenience class to centralize all error codes which are sent via broadcast
     */
    public static class Error {
        // General errors
        public static final int NO_EMITTERS_AVAILABLE = 0x2001;
        public static final int NO_DETECTORS_AVAILABLE = 0x2002;
        public static final int REQUIRE_INTERNET_CONNECTIVITY = 0x2003;
        public static final int DETECTOR_NOT_AVAILABLE = 0x2004;

        // Audio errors
        public static final int AUDIO_EMISSION_ERROR = 0x2011;
    }

    /**
     * Convenience class to centralize all detection codes which are sent via broadcast
     */
    public static class Detection {
        public static final int SIGNAL_DETECTED = 0x3001;
    }
}
