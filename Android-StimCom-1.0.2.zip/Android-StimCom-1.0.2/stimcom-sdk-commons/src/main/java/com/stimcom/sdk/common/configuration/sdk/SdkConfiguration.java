package com.stimcom.sdk.common.configuration.sdk;

import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.messages.Messenger;

import java.util.Set;

/**
 * Configuration of the SDK as provided by the user
 * <p/>
 * Created by vprat on 01/07/2015.
 */
public interface SdkConfiguration {

    /**
     * The type of messenger we want to use (optional, defaults to LocalBroadcaster)
     *
     * @return The type of messenger
     */
    Messenger.Type getMessengerType();

    /**
     * List of detector types requested by the user (required)
     *
     * @return The list of detector types
     */
    Set<Detector.Type> getRequestedDetectorTypes();

    /**
     * List of emitter types requested by the user (required)
     *
     * @return The list of emitter types
     */
    Set<Emitter.Type> getRequestedEmitterTypes();
}
