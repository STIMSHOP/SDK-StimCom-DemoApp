package com.stimcom.sdk.common.initializer;

import android.support.annotation.Nullable;

import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.messages.Messages;

import java.util.Map;

/**
 * The contract for an object which sets up the SDK. The initializer is started using the
 * {@link Initializer#run(Callback)} method. This method should be quick to execute and can be run asynchronously if
 * required.
 * <p/>
 * The initializer should call each method of the callback in its process. When the process is completed, we want to
 * call the {@link }
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public interface Initializer {

    /**
     * Used to pass information as we progress in the initialization process
     */
    interface Callback {

        /**
         * Called when the emitters have been instantiated and checked
         *
         * @param emitters The emitters which are usable on this device
         */
        void onEmittersReady(Map<Emitter.Type, Emitter> emitters);

        /**
         * Called when the detectors have been instantiated and checked
         *
         * @param detectors The detectors which are usable on this device
         */
        void onDetectorsReady(Map<Detector.Type, Detector> detectors);

        /**
         * Called when the initialization process is finished
         * @param success If the manager is ready or not
         */
        void onFinished(boolean success);

        /**
         * Called when something went wrong
         *
         * @param errorCode The error code from {@link Messages.Error}
         * @param errorMessage A more descriptive message (optional)
         */
        void onError(int errorCode, @Nullable String errorMessage);
    }

    /**
     * Run the initializer
     *
     * @param callback The listener which should get notified when we are done initializing
     */
    void run(Callback callback);

}
