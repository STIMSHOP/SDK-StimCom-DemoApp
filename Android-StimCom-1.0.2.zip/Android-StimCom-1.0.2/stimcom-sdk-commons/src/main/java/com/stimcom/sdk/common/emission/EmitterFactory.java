package com.stimcom.sdk.common.emission;

import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;

import java.util.Map;

/**
 * The contract for the factory to create objects which emit signals
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public interface EmitterFactory {

    /**
     * Create all emitters which are enabled in the given configuration
     *
     * @param sdkConfiguration The SDK configuration
     * @return A map of emitter instances indexed by type
     */
    Map<Emitter.Type, Emitter> createFromConfiguration(SdkConfiguration sdkConfiguration);

    /**
     * Create a emitter given its type
     *
     * @param type             The type of emitter we need
     * @param sdkConfiguration The SDK configuration
     * @return A proper implementation for the required emitter type
     */
    Emitter create(Emitter.Type type, SdkConfiguration sdkConfiguration);

}
