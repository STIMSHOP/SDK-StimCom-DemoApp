package com.stimcom.sdk.audio.utils;


/**
 * @author Romain This class handles the main Signal Transforms functions Static
 *         definitions for now Based on math3 from the Apache Foundation
 */
public class TsUtils {

    public static final double M_PI = 3.14159265359;


    public static double goertzel(double[] sig, double FREQ, int numSamples, int SAMPLING_RATE) {
        int k, i;
        double coeff, q0, q1, q2, magnitude, real, imag;
        double floatnumSamples, omega, sine, cosine;
        double scalingFactor = numSamples / 2.0;

        floatnumSamples = (double) numSamples;
        k = (int) (0.5 + ((numSamples * FREQ) / SAMPLING_RATE));
        omega = ((2.0 * M_PI * k) / floatnumSamples);
        sine = Math.sin(omega);
        cosine = Math.cos(omega);
        coeff = 2.0 * cosine;
        q0 = 0;
        q1 = 0;
        q2 = 0;

        for (i = 0; i < numSamples; i++) {
            q0 = coeff * q1 - q2 + sig[i];
            q2 = q1;
            q1 = q0;
        }

        // calculate the real and imaginary results
        // scaling appropriately
        real = (q1 - q2 * cosine) / scalingFactor;
        imag = (q2 * sine) / scalingFactor;

        magnitude = Math.sqrt(real * real + imag * imag);
        return magnitude;
    }

    public static void Teager(double[] Signal, double[] Output, int lenSignal) {
        // lenSignal is the length of the signal
        // Signal is real
        for (int i = 1; i < lenSignal - 1; i++) {
            Output[i] = Signal[i] * Signal[i] - Signal[i - 1] * Signal[i + 1];
        }
        // Interpolation for first and last sample
        Output[0] = 2 * Output[1] - Output[2];
        Output[lenSignal - 1] = 2 * Output[lenSignal - 2]
                - Output[lenSignal - 3];
        // Signal = Output;
    }

    public static void Teager(float[] Signal, float[] Output, int lenSignal) {
        // lenSignal is the length of the signal
        // Signal is real
        for (int i = 1; i < lenSignal - 1; i++) {
            Output[i] = Signal[i] * Signal[i] - Signal[i - 1] * Signal[i + 1];
        }
        // Interpolation for first and last sample
        Output[0] = 2 * Output[1] - Output[2];
        Output[lenSignal - 1] = 2 * Output[lenSignal - 2]
                - Output[lenSignal - 3];
        // Signal = Output;
    }

    public static void tukeywin(double[] tukey, int nSamples, float alpha) {
        int di = (int) Math.ceil(nSamples * alpha);

        double[] hann = new double[di];
        int i;
        for (i = 0; i < di; i++) {
            hann[i] = 0.5 * (1 - Math.cos(2 * M_PI * i / (di - 1)));
        }
        int lim = (int) Math.ceil(di / 2);

        for (i = 0; i < lim; i++) {
            tukey[i] = hann[i];
        }
        for (i = lim; i < nSamples - lim; i++) {
            tukey[i] = 1;
        }
        for (i = nSamples - lim; i < nSamples; i++) {
            tukey[i] = hann[i - (nSamples - di)];
        }
    }

    public static void tukeywin(float[] tukey, int nSamples, float alpha) {
        int di = (int) Math.ceil(nSamples * alpha);

        float[] hann = new float[di];
        int i;
        for (i = 0; i < di; i++) {
            hann[i] = (float) (0.5f * (1 - Math.cos((2 * M_PI * i / (di - 1)))));
        }
        int lim = (int) Math.ceil(di / 2);

        for (i = 0; i < lim; i++) {
            tukey[i] = hann[i];
        }
        for (i = lim; i < nSamples - lim; i++) {
            tukey[i] = 1;
        }
        for (i = nSamples - lim; i < nSamples; i++) {
            tukey[i] = hann[i - (nSamples - di)];
        }
    }

    public static void padVector(double[] vecIn, double[] vecOut, int size, int new_size) {
        int i;
        for (i = 0; i < size; i++) {
            vecOut[i] = vecIn[i];
        }
        // for (i=size;i<new_size;i++){ vecOut[i] = 0.0f;}
    }

    public static void padVector(float[] vecIn, float[] vecOut, int new_size) {
        for (int i = 0; i < vecIn.length; i++) {
            vecOut[i] = vecIn[i];
        }

    }

    public static void prepadVector(float[] vecIn, float[] vecOut, int pretamp) {
        for (int i = 0; i < vecIn.length; i++) {
            vecOut[i + pretamp] = vecIn[i];
        }
    }

    public static MaxValIndexFloat findMaxIndexFloat(float[] data, int size, int startPos) {
        MaxValIndexFloat res = new MaxValIndexFloat();
        int i;
        for (i = startPos; i < startPos + size; i++) {
            if (data[i] > res.max) {
                res.max = data[i];
                res.index = i;
            }
        }
        return res;
    }

    public static float[] fromDoubleToFloatArray(double[] toConvert) {
        float[] res = new float[toConvert.length];
        for (int i = 0; i < toConvert.length; i++) {
            res[i] = (float) (32767 * toConvert[i]);
        }
        return res;
    }

    public static double[] fromFloatToDoubleArray(float[] toConvert) {
        double[] res = new double[toConvert.length];
        for (int i = 0; i < toConvert.length; i++) {
            res[i] = Double.valueOf(toConvert[i]);
        }
        return res;
    }

    public static short[] fromFloatToShortArray(float[] toConvert) {
        short[] res = new short[toConvert.length];
        for (int i = 0; i < toConvert.length; i++) {
            res[i] = (short) (toConvert[i]);
        }
        return res;
    }

    public static float kurtosis(float[] values, float max) {

        // Moyenne des valeurs
        float sum = 0.0f;
        for (float f : values) {
            sum += f / max;
        }

        float mean = sum / (float) values.length;
        float num = 0.0f;
        float denom = 0.0f;

        for (float f : values) {
            num += Math.pow(f / max - mean, 4);
            denom += Math.pow(f / max - mean, 2);

        }

        num *= values.length;
        //log("kurtosis num " + num );
        //log("kurtosis denom " + denom);

        denom = (float) Math.pow(denom, 2);

        if (denom == 0.f) {
            return 0;
        } else {
            //log("kurtosis num " + num );
            //log("kurtosis denom " + denom);
            return num / denom;
        }


    }

//    static public void logText(short data[], String name) throws FileNotFoundException {
//        // name : custom file name to save the data. (j'utilise 		String blop = ((Thread.currentThread()).toString()).substring(14,18); dans le corps de la fonction ca donne un indicateur du thread)
//        short[] tempData = Arrays.copyOf(data, data.length);
//        String str = Arrays.toString(tempData);
//        str = str.replace("[", "");
//        str = str.replace("]", "");
//        str = str.replace(',', '\n');
//        File dataDir = new File(Environment.getExternalStorageDirectory().getPath() + "/logsStimCom/");
//        if (!dataDir.exists()) {
//            dataDir.mkdir();
//        }
//        File aFile = new File(dataDir, "" + name + ".txt");
//        FileOutputStream stream = null;
//        stream = new FileOutputStream(aFile);
//
//        try {
//            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(stream);
//            outputStreamWriter.write(str);
//            outputStreamWriter.close();
//        } catch (IOException e) {
//            Log.e("exception", "File write failed: " + e.toString());
//        }
//    }
//
//    static public void logText(float data[], String name) throws FileNotFoundException {
//        // name : custom file name to save the data. (j'utilise 		String blop = ((Thread.currentThread()).toString()).substring(14,18); dans le corps de la fonction ca donne un indicateur du thread)
//        float[] tempData = Arrays.copyOf(data, data.length);
//        String str = Arrays.toString(tempData);
//        str = str.replace("[", "");
//        str = str.replace("]", "");
//        str = str.replace(',', '\n');
//        File dataDir = new File(Environment.getExternalStorageDirectory().getPath() + "/logsStimCom/");
//        if (!dataDir.exists()) {
//            dataDir.mkdir();
//        }
//        File aFile = new File(dataDir, "" + name + ".txt");
//        FileOutputStream stream = null;
//
//        stream = new FileOutputStream(aFile);
//
//        try {
//            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(stream);
//            outputStreamWriter.write(str);
//            outputStreamWriter.close();
//        } catch (IOException e) {
//            Log.e("exception", "File write failed: " + e.toString());
//        }
//    }

}
