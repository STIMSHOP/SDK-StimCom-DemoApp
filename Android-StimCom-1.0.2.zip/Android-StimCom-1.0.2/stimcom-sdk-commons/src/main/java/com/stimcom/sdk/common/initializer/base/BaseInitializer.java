package com.stimcom.sdk.common.initializer.base;

import android.content.Context;

import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.detection.DefaultDetectorFactory;
import com.stimcom.sdk.common.detection.DetectorFactory;
import com.stimcom.sdk.common.emission.DefaultEmitterFactory;
import com.stimcom.sdk.common.emission.EmitterFactory;
import com.stimcom.sdk.common.initializer.Initializer;
import com.stimcom.sdk.common.messages.Messenger;

/**
 * An initializer which will perform its job using an AsyncTask
 * <p/>
 * Created by vprat on 02/07/2015.
 */
public class BaseInitializer implements Initializer {

    private Context context;
    private DetectorFactory detectorFactory;
    private EmitterFactory emitterFactory;
    private SdkConfiguration sdkConfiguration;

    /**
     * Constructor
     *
     * @param context          The application context
     * @param sdkConfiguration The SDK configuration
     * @param messenger        The Messenger
     */
    public BaseInitializer(Context context, SdkConfiguration sdkConfiguration, Messenger messenger) {
        this(context,
                sdkConfiguration,
                new DefaultDetectorFactory(context, messenger),
                new DefaultEmitterFactory(context, messenger));
    }

    /**
     * Constructor
     *
     * @param context          The application context
     * @param sdkConfiguration The SDK configuration
     * @param detectorFactory  The factory to create detectors from the configuration
     * @param emitterFactory   The factory to create emitters from the configuration
     */
    public BaseInitializer(Context context,
                           SdkConfiguration sdkConfiguration,
                           DetectorFactory detectorFactory,
                           EmitterFactory emitterFactory) {
        this.context = context;
        this.sdkConfiguration = sdkConfiguration;
        this.detectorFactory = detectorFactory;
        this.emitterFactory = emitterFactory;
    }

    @Override
    public void run(Callback callback) {
        BaseInitializerTask task = new BaseInitializerTask(
                context,
                detectorFactory,
                emitterFactory,
                sdkConfiguration,
                callback);

        task.execute();
    }
}
