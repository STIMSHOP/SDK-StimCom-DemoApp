package com.stimcom.sdk.common.initializer.base;

import android.content.Context;
import android.os.AsyncTask;

import com.google.common.collect.Maps;
import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.detection.DetectorFactory;
import com.stimcom.sdk.common.emission.Emitter;
import com.stimcom.sdk.common.emission.EmitterFactory;
import com.stimcom.sdk.common.initializer.Initializer;
import com.stimcom.sdk.common.messages.Messages;
import com.stimcom.sdk.common.utils.Timber;

import java.util.Collection;
import java.util.Map;

/**
 * AsyncTask which will perform the initialization
 * <p/>
 * Created by vprat on 02/07/2015.
 */
class BaseInitializerTask extends AsyncTask<Void, Void, Boolean> {

    private final Context context;
    private final EmitterFactory emitterFactory;
    private final DetectorFactory detectorFactory;
    private final SdkConfiguration sdkConfiguration;
    private final Initializer.Callback callback;

    private Map<Detector.Type, Detector> detectors;
    private Map<Emitter.Type, Emitter> emitters;

    /**
     * Constructor
     *
     * @param detectorFactory  The factory which will create the detectors
     * @param sdkConfiguration The SDK configuration
     * @param callback         The callback to notify of our status
     */
    public BaseInitializerTask(Context context,
                               DetectorFactory detectorFactory,
                               EmitterFactory emitterFactory,
                               SdkConfiguration sdkConfiguration,
                               Initializer.Callback callback) {
        this.context = context;
        this.detectorFactory = detectorFactory;
        this.emitterFactory = emitterFactory;
        this.sdkConfiguration = sdkConfiguration;
        this.callback = callback;
    }

    @Override
    protected Boolean doInBackground(Void[] params) {
        if (!createDetectors()) return false;
        if (!createEmitters()) return false;

        callback.onDetectorsReady(detectors);
        callback.onEmittersReady(emitters);

        return true;
    }

    @Override
    protected void onPostExecute(Boolean success) {
        callback.onFinished(success);
    }

    /**
     * Create the detectors. This requires the API configuration to be properly initialized.
     */
    private boolean createDetectors() {
        detectors = Maps.newEnumMap(Detector.Type.class);

        Collection<Detector> configuredDetectors = detectorFactory.createFromConfiguration(sdkConfiguration)
                .values();
        for (Detector detector : configuredDetectors) {
            if (!detector.isSupported()) {
                Timber.w("Detector has been requested for type %1$s but is not supported on this device",
                        detector.getType().name());

                callback.onError(
                        Messages.Error.DETECTOR_NOT_AVAILABLE,
                        String.format("Detector has been requested for type %1$s but is not supported on this device",
                                detector.getType().name()));

                // Skip this detector as it cannot be used on this device
                continue;
            }
            detectors.put(detector.getType(), detector);
        }

        if (detectors.isEmpty()) {
            callback.onError(
                    Messages.Error.NO_DETECTORS_AVAILABLE,
                    "Either you have not configured any detector, or this device does not support them");
            return false;
        }

        return true;
    }

    /**
     * Create the emitters. This requires the API configuration to be properly initialized.
     */
    private boolean createEmitters() {
        emitters = Maps.newEnumMap(Emitter.Type.class);

        Collection<Emitter> configuredEmitters = emitterFactory.createFromConfiguration(sdkConfiguration)
                .values();
        for (Emitter emitter : configuredEmitters) {
            if (!emitter.isSupported()) {
                Timber.w("Emitter has been requested for type %1$s but is not supported on this device",
                        emitter.getType().name());

                // TODO Send a warning somehow (listener? broadcast?)

                // Skip this emitter as it cannot be used on this device
                continue;
            }
            emitters.put(emitter.getType(), emitter);
        }

        if (emitters.isEmpty()) {
            callback.onError(
                    Messages.Error.NO_EMITTERS_AVAILABLE,
                    "Either you have not configured any emitter, or this device does not support them");
            return false;
        }

        return true;
    }
}
