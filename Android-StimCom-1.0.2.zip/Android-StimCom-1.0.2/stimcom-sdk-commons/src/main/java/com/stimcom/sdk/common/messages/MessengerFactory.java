package com.stimcom.sdk.common.messages;

import android.support.annotation.NonNull;

/**
 * Created by vprat on 03/12/2015.
 */
public interface MessengerFactory {

    /**
     * Create a messenger based on the required type
     *
     * @param type The type of messenger to create (see the String constants of this class)
     * @return The messenger instance
     */
    Messenger newMessenger(@NonNull Messenger.Type type);

}
