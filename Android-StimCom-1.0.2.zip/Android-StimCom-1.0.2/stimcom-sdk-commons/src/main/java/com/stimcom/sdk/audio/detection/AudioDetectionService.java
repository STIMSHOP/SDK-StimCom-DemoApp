package com.stimcom.sdk.audio.detection;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import com.stimcom.sdk.audio.analysis.Analyzer;
import com.stimcom.sdk.audio.analysis.SignalAnalyzedListener;
import com.stimcom.sdk.audio.analysis.StartDetectedListener;
import com.stimcom.sdk.audio.analysis.StartDetector;
import com.stimcom.sdk.audio.Constants;
import com.stimcom.sdk.audio.utils.Decoder;
import com.stimcom.sdk.audio.utils.Indices;
import com.stimcom.sdk.common.StimCom;
import com.stimcom.sdk.common.configuration.sdk.SdkConfiguration;
import com.stimcom.sdk.common.detection.AbstractDetectionService;
import com.stimcom.sdk.common.detection.Detector;
import com.stimcom.sdk.common.detection.Proximity;
import com.stimcom.sdk.common.messages.Messenger;
import com.stimcom.sdk.common.model.Signal;
import com.stimcom.sdk.common.utils.Timber;

import java.util.List;

/**
 * Service handling audio detection
 */
public class AudioDetectionService extends AbstractDetectionService {

    /**
     * Get the Intent to start or stop this service
     *
     * @param context The context
     * @return The intent
     */
    public static Intent newIntent(Context context) {
        return new Intent(context, AudioDetectionService.class);
    }

    // region State management

    // Looks hacky to you? Well, me too but here is the source:
    // http://stackoverflow.com/questions/600207/how-to-check-if-a-service-is-running-on-android
    //
    // Looks ok because our services are local.
    public static boolean isRunning = false;

    public static boolean isRunning() {
        return isRunning;
    }

    private static void setIsRunning(boolean isRunning) {
        AudioDetectionService.isRunning = isRunning;
    }

    // endregion

    private StimCom stimCom;
    private SdkConfiguration sdkConfiguration;
    private Messenger messenger;

    private StartDetector detector;
    private Decoder decoder;
    private Analyzer analyzer;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        stimCom = StimCom.get();

        if (!stimCom.isReady()) {
            Timber.w("Audio detection service started but StimCom is not ready yet. Bailing.");
            return;
        }

        // Initialize our components
        messenger = stimCom.getMessenger();
        sdkConfiguration = stimCom.getSdkConfiguration();

        // Instantiate the messaging pipe
        detector = new StartDetector(Constants.SAMPLE_RATE, Constants.NB_BUFFER_ANALYZED, Constants.BASE_BUFFER_SIZE, Constants.F1 - 2 * Constants.GAP, Constants.F2 + 2 * Constants.GAP);
        analyzer = new Analyzer(Constants.SAMPLE_RATE, Constants.BASE_BUFFER_SIZE, Constants.NB_CHAR + Constants.NB_CRC, Constants.F1, Constants.F2, Constants.NB_FREQ);
        decoder = new Decoder(Constants.NB_CHAR, Constants.NB_CRC);

        // Attach this as a listener
        detector.setListener(startDetectedListener);
        analyzer.setListener(analyzedListener);

        // Start detecting signals
        detector.startDetection();
        setIsRunning(true);
    }

    @Override
    public void onDestroy() {
        detector.stopDetection();
        detector.setListener(null);
        analyzer.setListener(null);

        // Just in case
        detector = null;
        decoder = null;
        analyzer = null;

        // Ok. we're not in business anymore
        setIsRunning(false);

        super.onDestroy();
    }

    private SignalAnalyzedListener analyzedListener = new SignalAnalyzedListener() {
        @Override
        public void onSignalAnalyzed(List<Indices> analyzed) {
            if (stimCom.isDebugEnabled()) {
                Timber.d("onSignalAnalyzed : " + analyzed.size() + " indices");
                messenger.sendOnDebugInformation("Audio.onSignalAnalyzed");
            }

            String decoded = decoder.decode(analyzed);
            if (decoded != null) {
                Signal s = new Signal();
                s.code = decoded;

                messenger.sendOnSignalDetected(Detector.Type.AUDIO, s, Proximity.UNKNOWN);

                if (stimCom.isDebugEnabled()) {
                    Timber.d("onSignalDecoded  : " + decoded);
                }
            }
        }

        @Override
        public void onSignalAnalyzisError() {
            if (stimCom.isDebugEnabled()) {
                Timber.d("onSignalAnalyzisError");
                messenger.sendOnDebugInformation("Audio.onSignalAnalyzisError");
            }
        }
    };


    private StartDetectedListener startDetectedListener = new StartDetectedListener() {
        @Override
        public void onSignalReceived(float[] recorded) {
            analyzer.onSignalReceived(recorded);

            if (stimCom.isDebugEnabled()) {
                Timber.d("onSignalReceived : " + recorded.length);
                messenger.sendOnDebugInformation("Audio.onSignalReceived");
            }
        }
    };
}
