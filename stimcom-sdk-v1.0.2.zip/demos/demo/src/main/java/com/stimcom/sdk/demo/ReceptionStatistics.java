package com.stimcom.sdk.demo;

import com.google.common.base.Optional;
import com.google.common.base.Strings;

/**
 * Compute statistics about current reception
 * <p/>
 * Created by vprat on 03/12/2015.
 */
public class ReceptionStatistics {

    private Optional<String> expectedSignal = Optional.absent();
    private Optional<Double> period = Optional.absent();

    private int numDetections;
    private int numAnalysis;
    private int numDecodedSignals;
    private int numCorrectSignals;
    private long startTime;
    private long lastDecodedMessageTimestamp;

    public ReceptionStatistics(String expectedSignal, Double period) {
        startTime = System.currentTimeMillis();
        lastDecodedMessageTimestamp = -1;

        numDetections = 0;
        numAnalysis = 0;
        numCorrectSignals = 0;
        numDecodedSignals = 0;

        this.expectedSignal = Strings.isNullOrEmpty(expectedSignal) ? Optional.<String>absent() : Optional.of(expectedSignal);
        this.period = Optional.fromNullable(period);
    }

    public ReceptionStatistics() {
        this(null, null);
    }

    public ReceptionStatistics newAnalysis() {
        numAnalysis++;

        return this;
    }

    public ReceptionStatistics newDetection() {
        numDetections++;

        return this;
    }

    public ReceptionStatistics newSignal(String signal) {
        long now = System.currentTimeMillis();

        if (period.isPresent()) {
            if (now - lastDecodedMessageTimestamp < period.get() * 800) {
                return this;
            }
        }

        numDecodedSignals++;
        lastDecodedMessageTimestamp = now;
        if (expectedSignal.isPresent() && expectedSignal.get().equalsIgnoreCase(signal)) {
            numCorrectSignals++;
        }

        return this;
    }

    @Override
    public String toString() {
        long duration = System.currentTimeMillis() - startTime;
        int numEmissions = (int) ((0.001 * duration) / period.get()); // seconds everywhere

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Duration:        %d sec\n", duration / 1000));
        sb.append(String.format("Detections:      %d (%.1f%%)\n", numDetections, 100.0f * numDetections / numEmissions));
        sb.append(String.format("Analysis:        %d (%.1f%%)\n", numAnalysis, 100.0f * numAnalysis / numEmissions));
        sb.append(String.format("Decoded:         %d (%.1f%%)\n", numDecodedSignals, 100.0f * numDecodedSignals / numEmissions));

        if (expectedSignal.isPresent() && period.isPresent()) {
            sb.append(String.format("Expected code:   %s\n", expectedSignal.get()));
            sb.append(String.format("Correct signals: %d (%.1f%%)\n", numCorrectSignals, 100.0f * numCorrectSignals / numEmissions));
            sb.append(String.format("False positives: %d (%.1f%%)\n", numDecodedSignals - numCorrectSignals, 100.0f * (numDecodedSignals - numCorrectSignals) / numEmissions));
        }

        return sb.toString();
    }
}
