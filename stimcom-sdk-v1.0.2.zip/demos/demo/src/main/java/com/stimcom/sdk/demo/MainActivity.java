package com.stimcom.sdk.demo;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.Toast;

import com.stimcom.sdk.common.StimCom;
import com.stimcom.sdk.common.messages.broadcaster.AbstractBroadcaster;
import com.stimcom.sdk.common.messages.broadcaster.StimComBroadcastReceiver;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_RECORD_AUDIO_PERMISSION = 0x0012;

    // region Our views

    @Bind(R.id.btn_emission)
    Button emissionButton;

    @Bind(R.id.btn_reception)
    Button receptionButton;

    // endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Register the local broadcast receiver at activity level
        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,
                new IntentFilter(AbstractBroadcaster.ACTION_RECEIVE_MESSAGES));

        checkRequiredPermissions();
    }

    @Override
    protected void onPause() {
        // Don't forget to unregister the receiver. Else you'll leak the context, and hence, memory!
        LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);

        super.onPause();
    }

    @OnClick(R.id.btn_emission)
    public void onEmissionButtonClicked() {
        Intent intent = new Intent(this, EmissionActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.btn_reception)
    public void onReceptionButtonClicked() {
        if (checkRequiredPermissions()) {
            Intent intent = new Intent(this, ReceptionActivity.class);
            startActivity(intent);
        }
    }

    // region Permissions handling

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_RECORD_AUDIO_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    StimCom.create(this)
                            .enableDebug(true)
                            .start();
                } else {
                    Toast.makeText(this, R.string.act_record_audio_permission_missing, Toast.LENGTH_LONG).show();
                }

                break;
            }
        }
    }

    /**
     * We need to check that the user has given all the required permissions to the application
     * else the detectors cannot be initialized.
     *
     * @return true if the permissions are granted
     */
    protected boolean checkRequiredPermissions() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.RECORD_AUDIO)) {
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setMessage(R.string.act_record_audio_permission_hint)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                checkRequiredPermissions();
                            }
                        })
                        .show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.RECORD_AUDIO},
                        REQUEST_RECORD_AUDIO_PERMISSION);
            }

            return false;
        }

        return true;
    }

    // endregion


    // Listens to the detection messages
    private StimComBroadcastReceiver myReceiver = new StimComBroadcastReceiver() {
        @Override
        protected void onGenericError(Context context, int code, @Nullable String details) {
            Toast.makeText(MainActivity.this, details, Toast.LENGTH_SHORT).show();
        }
    };
}
