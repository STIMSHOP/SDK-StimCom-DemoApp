Version history
===============

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->


- [1.0
](#10)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

1.0
---

- `new` - Demo application, can be used for development
- `new` - SDK to detect and emit signals using audio